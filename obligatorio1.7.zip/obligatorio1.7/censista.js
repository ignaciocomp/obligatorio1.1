//---------------------------PERFIL CENSISTA------------------------------------------------------
//ARRAYS CLASES Y VARIABLES
class Censista {
    constructor(nombre, usuario, contraseña) {
        this.nombre = nombre.toLowerCase();
        this.usuario = usuario.toLowerCase();
        this.contraseña = contraseña;
    }
    validarCredenciales(usuario, contraseña) {
        return (
            this.usuario === usuario.toLowerCase() && this.contraseña === contraseña);
    }
}
class Persona {
    constructor(nombre, apellido, edad, cedula, departamento, ocupacion, censado, censista) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.cedula = cedula;
        this.departamento = departamento;
        this.ocupacion = ocupacion;
        this.censado = censado;
        this.censista = censista;
    }
}
let usuarioActivo = ""
let censistas = [];
let usuariosCreados = [];
let cedulasCensadas = ["1234"];
let departamentos = [
    "Artigas",
    "Canelones",
    "Cerro Largo",
    "Colonia",
    "Durazno",
    "Flores",
    "Florida",
    "Lavalleja",
    "Maldonado",
    "Montevideo",
    "Paysandú",
    "Río Negro",
    "Rivera",
    "Rocha",
    "Salto",
    "San José",
    "Soriano",
    "Tacuarembó",
    "Treinta y Tres"
];
let verificar = []
let ocupaciones = [
    "Dependiente",
    "Independiente",
    "Estudiante",
    "No trabaja"
];











//---------------------------REGISTRAR CENSISTA---------------------------------------------------
function verificarNombreUsuarioUnico(usuario) {
    for (let i = 0; i < usuariosCreados.length; i++) {
        if (usuariosCreados[i].usuario === usuario) {
            return false;
        }
    }
    return true;
}
function verificarContraseñaValida(contraseña) {
    let tieneMinusc = false;
    let tieneMayusc = false;
    let tieneNumero = false;
    for (let i = 0; i < contraseña.length; i++) {
        let char = contraseña[i];
        if (char >= 'a' && char <= 'z') {
            tieneMinusc = true;
        } else if (char >= 'A' && char <= 'Z') {
            tieneMayusc = true;
        } else if (char >= '0' && char <= '9') {
            tieneNumero = true;
        }
    }
    return tieneMinusc && tieneMayusc && tieneNumero && contraseña.length >= 5;    //SI TODO ES TRUE LO RETURNEA
}
function registrarCensista(nombre, usuario, contraseña) {
    if (!verificarNombreUsuarioUnico(usuario)) {
        alert("El nombre de usuario ya está en uso. Por favor, elige otro.");
        return;
    }
    if (!verificarContraseñaValida(contraseña)) {
        alert("La contraseña no cumple con los requisitos mínimos.");
        return;
    }
    let nuevoCensista = new Censista(nombre, usuario, contraseña);
    censistas.push(nuevoCensista)
    usuariosCreados.push(nuevoCensista);
    alert("Censista registrado con éxito.");
    document.querySelector("#txtNombre1").value = '';
    document.querySelector("#txtUsuario1").value = '';
    document.querySelector("#txtContraseña1").value = '';
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
}
function tomarValores1() {
    let nombre = document.querySelector("#txtNombre1").value;
    let usuario = document.querySelector("#txtUsuario1").value;
    let contraseña = document.querySelector("#txtContraseña1").value;
    if (nombre.trim() === '') {    //aca se verifica que los campos no esten vacios
        alert("El campo de nombre es obligatorio.");
        return;
    }
    if (usuario.trim() === '') {
        alert("El campo de usuario es obligatorio.");
        return;
    }
    if (contraseña.trim() === '') {
        alert("El campo de contraseña es obligatorio.");
        return;
    }
    if (contraseña.length < 5) {
        alert("La contraseña debe tener al menos 5 caracteres.");
        return;
    }
    let tieneMinusc = false;
    let tieneMayusc = false;
    let tieneNumero = false;
    for (let i = 0; i < contraseña.length; i++) {
        const char = contraseña[i];
        if (char >= 'a' && char <= 'z') {
            tieneMinusc = true;
        } else if (char >= 'A' && char <= 'Z') {
            tieneMayusc = true;
        } else if (char >= '0' && char <= '9') {
            tieneNumero = true;
        }
    }
    if (!tieneMinusc) {
        alert("La contraseña debe contener al menos una letra minúscula.");
        return;
    }
    if (!tieneMayusc) {
        alert("La contraseña debe contener al menos una letra mayúscula.");
        return;
    }
    if (!tieneNumero) {
        alert("La contraseña debe contener al menos un número.");
        return;
    }
    registrarCensista(nombre, usuario, contraseña);
}
document.querySelector("#btnRegistrar").addEventListener("click", tomarValores1);













//---------------------------INGRESAR CENSISTA-----------------------------------------------------
function IngresarCensista() {
    let usuario = document.querySelector('#txtUsuario2').value;
    let contraseña = document.querySelector('#txtContraseña2').value;
    let censistaValido = null;    // ACA DECLARA censitaValido como NULL y PASA POR LA FUNCION DE VALIDARCREDENCIALES
    for (let i = 0; i < censistas.length; i++) {
        let censista = censistas[i];
        if (censista.validarCredenciales(usuario, contraseña)) {
            censistaValido = censista;
            break;
        }
    }
    if (censistaValido) {    //SI CENSISTA ES VALIDO TE MANDA A LA PAGINA INGRESAR DATOS SINO TE DA ERROR
        usuarioActivo = censistaValido.nombre;
        document.querySelector("#btnUsuarioCensistaActivo").innerHTML = ""
        document.querySelector("#btnUsuarioCensistaActivo").innerHTML = "Usuario Activo: " + usuarioActivo
        cambiarSeccion("seccionIngresarDatos")
        cargarPersonasPendientes();
        cargarCensistasDisponibles();
        alert("Censista Ingresado con exito")
    } else {
        alert('Credenciales incorrectas. Por favor, verifícalas.');
    }
    document.querySelector('#txtUsuario2').value = ""
    document.querySelector('#txtContraseña2').value = ""
};
document.querySelector('#btnIngresar').addEventListener('click', IngresarCensista)














//---------------------------INGRESAR DATOS---------------------------
let departamentoSelect = document.querySelector("#txtDepartamento3");
let cedulaInput = document.querySelector("#txtCedula3");
let ocupacionSelect = document.querySelector("#txtOcupacion3");
let censadoSelect = document.querySelector('#txtCensado3')
function cargarDepartamentos() {
    for (let i = 0; i < departamentos.length; i++) { //recorre el array de departamentos y los carga dinamicamente en el option del HTML
        let departamento = departamentos[i];
        let option = document.createElement("option");
        option.value = departamento;
        option.textContent = departamento;
        departamentoSelect.appendChild(option); //se inserta el elemento option con su value y text content como una nueva opción dentro del menú desplegable, y se repite hasta terminar el bucle
    }
}
function esCedulaDuplicada(cedula) {
    return cedulasCensadas.includes(cedula);//si la cedula ingresada inculdes CEDULA entonces es que la cedula ya existe
}
function validarFormulario() {
    let nombre = document.querySelector("#txtNombre3").value.trim();// ELIMINA ESPACIOS EN BLANCO AL PRINCIPIO Y FINAL
    let apellido = document.querySelector("#txtApellido3").value.trim();// ELIMINA ESPACIOS EN BLANCO AL PRINCIPIO Y FINAL
    let edad = document.querySelector("#txtEdad3").value;
    let cedula = cedulaInput.value.replace(/[^0-9]/g, "");//remueve puntos guiones espacios letras TODO lo q no sea numeros lo remueve
    let departamento = departamentoSelect.value;
    let ocupacion = ocupacionSelect.value;
    let censado = censadoSelect.value;
    //verifica si algun campo quedo vacio
    if (usuarioActivo === "invitado") {
    } else if (usuarioActivo === "") {
        alert("Debe Ingresar con su Nombre, Usuario y Contraseña primero.");
        return false;
    }
    if (nombre === "") {
        alert("El nombre no puede estar vacío.");
        return false;
    }
    if (apellido === "") {
        alert("El apellido no puede estar vacío.");
        return false;
    }
    if (edad === "") {
        alert("La edad no puede estar vacía.");
        return false;
    }
    if (!(edad > 0 && edad < 130)) {
        alert("La edad es Incorrecta.");
        return false;
    }
    if (cedula === "") {
        alert("La cédula no puede estar vacía.");
        return false;
    }
    if (departamento === "") {
        alert("Debe seleccionar un departamento de residencia.");
        return false;
    }
    if (ocupacion === "") {
        alert("Debe seleccionar una ocupación.");
        return false;
    }
    //verifica si la cedula ya esta censada
    if (esCedulaDuplicada(cedula)) {
        alert("Ya existe una persona censada para esta cédula.");
        return false;
    }
    if (censado === "") {
        alert("El campo Censado no puede quedar vacio")
        return false;
    }
    return true; // si pasa todas las verificaciones returnea TRUE, sino returnea false y tira alert
}
//al hacer click GUARDAR ejecuta la gran funcion validarFormulario(), si devuelve true, crea el objeto Persona y lo agrega al array de persona
function agregarDatos() {
    if (validarFormulario()) {
        let nombre = document.querySelector("#txtNombre3").value.trim();
        let apellido = document.querySelector("#txtApellido3").value.trim();
        let edad = document.querySelector("#txtEdad3").value;
        let cedula = cedulaInput.value.replace(/[^0-9]/g, "");
        let departamento = departamentoSelect.value;
        let ocupacion = ocupacionSelect.value;
        let censadoSelect = document.querySelector('#txtCensado3');
        let censadoValue = censadoSelect.value === "true"; // Convertir a booleano
        let persona = new Persona(nombre, apellido, edad, cedula, departamento, ocupacion, censadoValue, usuarioActivo);;//crea el objeto nuevo Persona
        personas.push(persona); // pushea al array de personas
        cedulasCensadas.push(cedula);// pushea al array de cedulas
        //mando un mensaje de notificacion con todos los datos que se cargaron al array de personas
        alert(`Datos válidos, se pueden guardar.
        Nombre: ${persona.nombre}
        Apellido: ${persona.apellido}
        Edad: ${persona.edad}
        Cédula: ${persona.cedula}
        Departamento: ${persona.departamento}
        Ocupación: ${persona.ocupacion}`);
        //resetea los campos de texto nuevamente para volver a ingresar nuevos textos
        document.querySelector("#txtNombre3").value = "";
        document.querySelector("#txtApellido3").value = "";
        document.querySelector("#txtEdad3").value = "";
        cedulaInput.value = "";
        departamentoSelect.value = "";
        ocupacionSelect.value = "";
    }
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
};
document.querySelector("#btnAgregar").addEventListener("click", agregarDatos)














//---------------------------VERIFICAR DATOS PRECARGADOS------------------------------------------------------
function verificarDatos() {
    verificar.splice(0, verificar.length)
    let cedula = document.querySelector('#txtCedula4').value;
    let personaEncontrada = null;
    if (cedula === "") {
        alert("El campo no puede estar vacío");
        return false;
    }
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].cedula === cedula) {
            if (personas[i].censado === true) {
                document.querySelector('#pVerificar').innerHTML = 'La cédula ya está Censada.';
                return false;
            } else {
                personaEncontrada = personas[i];
                break;
            }
        }
    }
    if (personaEncontrada) {
        AgregarSeccion("seccionIngresarDatos");
        document.querySelector("#btnConfirmar").removeAttribute("hidden");
        document.querySelector("#txtCedula3").setAttribute("disabled", "disabled");
        document.querySelector("#btnAgregar").setAttribute("hidden", "true");
        document.querySelector('#txtNombre3').value = personaEncontrada.nombre;
        document.querySelector('#txtApellido3').value = personaEncontrada.apellido;
        document.querySelector('#txtEdad3').value = personaEncontrada.edad;
        document.querySelector("#txtCedula3").value = personaEncontrada.cedula;
        document.querySelector('#txtDepartamento3').value = personaEncontrada.departamento;
        document.querySelector('#txtOcupacion3').value = personaEncontrada.ocupacion;
        document.querySelector('#txtCensado3').value = personaEncontrada.censado.toString();
    } else {
        document.querySelector('#pVerificar').innerHTML = 'La cédula no fue encontrada.';
    }
    verificar.push(personaEncontrada)
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
}
function ValidarCenso() {
    let cedula = document.querySelector('#txtCedula3').value;
    let personaEncontrada = null;
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].cedula === cedula) {
            personaEncontrada = personas[i];
            if (censadoSelect.value === "true") {
                personaEncontrada.censado = true;
            } else if (personaEncontrada.value === "false") {
                personaEncontrada.censado = false;
            }
        }
    }
    let nombre = document.querySelector("#txtNombre3").value.trim();
    let apellido = document.querySelector("#txtApellido3").value.trim();
    let edad = document.querySelector("#txtEdad3").value;
    let departamento = departamentoSelect.value;
    let ocupacion = ocupacionSelect.value; // Convertir a booleano

    personaEncontrada.nombre = nombre
    personaEncontrada.apellido = apellido
    personaEncontrada.edad = edad
    personaEncontrada.departamento = departamento
    personaEncontrada.ocupacion = ocupacion
    alert(`Datos Guardados.
        Nombre: ${personaEncontrada.nombre}
        Apellido: ${personaEncontrada.apellido}
        Edad: ${personaEncontrada.edad}
        Cédula: ${personaEncontrada.cedula}
        Departamento: ${personaEncontrada.departamento}
        Ocupación: ${personaEncontrada.ocupacion}
        Censista: ${personaEncontrada.censista}`);
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    //resetea los campos de texto nuevamente para volver a ingresar nuevos textos
    document.querySelector("#txtNombre3").value = "";
    document.querySelector("#txtApellido3").value = "";
    document.querySelector("#txtEdad3").value = "";
    cedulaInput.value = "";
    departamentoSelect.value = "";
    ocupacionSelect.value = "";
    document.querySelector("#txtCedula3").removeAttribute("disabled")
}
document.querySelector("#btnVerificar").addEventListener('click', verificarDatos);
document.querySelector("#btnConfirmar").addEventListener("click", ValidarCenso);














//---------------------------REASIGNAR PERSONA PARA VALIDAR------------------------------------------------------
let censista1 = new Censista("Juan", "juancensista", "Contrasena1");
let censista2 = new Censista("María", "mariacensista", "Contrasena3");
let censista3 = new Censista("Pedro", "pedrocensista", "Contrasena3");
censistas.push(censista1, censista2, censista3);
let personas = [
    new Persona("John", "Doe", 44, "1234567890", departamentos[0], ocupaciones[0], false, censistas[0].nombre),
    new Persona("Jane", "Smith", 32, "0987654321", departamentos[1], ocupaciones[2], false, censistas[1].nombre),
    new Persona("George", "Elin", 77, "5678901234", departamentos[2], ocupaciones[1], false, censistas[2].nombre),
    new Persona("Emily", "Brown", 50, "4321098765", departamentos[3], ocupaciones[3], false, censistas[0].nombre),
    new Persona("Daniel", "Miller", 28, "9876543210", departamentos[4], ocupaciones[4], false, censistas[1].nombre),
    new Persona("Olivia", "Davis", 35, "3456789012", departamentos[5], ocupaciones[2], false, censistas[2].nombre),
    new Persona("David", "Wilson", 45, "2109876543", departamentos[6], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Sophia", "Moore", 55, "6543210987", departamentos[7], ocupaciones[3], false, censistas[1].nombre),
    new Persona("Emma", "Taylor", 30, "8765432109", departamentos[8], ocupaciones[4], false, censistas[2].nombre),
    new Persona("Noah", "Anderson", 38, "9012345678", departamentos[9], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Liam", "Wilson", 42, "7654321098", departamentos[10], ocupaciones[2], false, censistas[1].nombre),
    new Persona("Ava", "Johnson", 29, "2345678901", departamentos[11], ocupaciones[3], false, censistas[2].nombre),
    new Persona("Ethan", "Miller", 48, "6789012345", departamentos[12], ocupaciones[1], true, censistas[0].nombre),
    new Persona("Mia", "Davis", 36, "5432109876", departamentos[13], ocupaciones[4], true, censistas[1].nombre),
    new Persona("Isabella", "Moore", 31, "8901234567", departamentos[14], ocupaciones[2], true, censistas[2].nombre),
    new Persona("James", "Taylor", 39, "4567890123", departamentos[15], ocupaciones[3], true, censistas[0].nombre),
    new Persona("Benjamin", "Anderson", 43, "0123456789", departamentos[16], ocupaciones[1], true, censistas[1].nombre),
    new Persona("Luna", "Smith", 27, "3210987654", departamentos[17], ocupaciones[4], true, censistas[2].nombre),
    new Persona("Elijah", "Johnson", 33, "7890123456", departamentos[18], ocupaciones[2], true, censistas[0].nombre),
    new Persona("Scarlett", "Brown", 41, "2109876541", departamentos[0], ocupaciones[3], true, censistas[1].nombre),
    new Persona("Alejandro", "Vazquez", 17, "1111111111", departamentos[1], ocupaciones[1], true, censistas[2].nombre),
    new Persona("Sophia", "Young", 35, "2222222222", departamentos[2], ocupaciones[2], true, censistas[0].nombre),
    new Persona("JuanIgnacio", "Mendez", 28, "3333333333", departamentos[3], ocupaciones[3], true, censistas[1].nombre),
    new Persona("Charlotte", "Anderson", 41, "4444444444", departamentos[4], ocupaciones[4], false, censistas[2].nombre),
    new Persona("Ignacio", "Compan", 19, "5555555555", departamentos[5], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Amelia", "Brown", 12, "6666666666", departamentos[6], ocupaciones[0], true, censistas[1].nombre),
    new Persona("Benjamin", "Smith", 37, "7777777777", departamentos[7], ocupaciones[2], true, censistas[2].nombre),
    new Persona("Ava", "Taylor", 23, "8888888888", departamentos[8], ocupaciones[3], false, censistas[0].nombre),
    new Persona("Noah", "Davis", 31, "9999999999", departamentos[9], ocupaciones[4], false, censistas[1].nombre),
    new Persona("Jorge", "Carrion", 31, "9999999999", departamentos[10], ocupaciones[1], true, censistas[2].nombre),
];
// Obtén referencias del HTML
let personasPendientesSelect = document.querySelector('#txtPersonasPendientes');
let censistasSelect = document.querySelector('#slcCensistas');
// Función para cargar las opciones de personas pendientes
function cargarPersonasPendientes() {
    personasPendientesSelect.innerHTML = '';    // Limpia las opciones existentes
    let optionDefault = document.createElement('option');    //opción por defecto Seleccione...
    optionDefault.value = '';
    optionDefault.textContent = 'Seleccione...';
    personasPendientesSelect.appendChild(optionDefault);
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].censado === false) {
            let option = document.createElement('option');
            option.value = personas[i].cedula;
            option.textContent = `${personas[i].nombre} ${personas[i].apellido}, CENSISTA: ${personas[i].censista}`;
            personasPendientesSelect.appendChild(option);
        }
    }
}
// Función para cargar las opciones de censistas disponibles
function cargarCensistasDisponibles() {
    censistasSelect.innerHTML = '';    // Limpia las opciones existentes
    let optionDefault = document.createElement('option');    //opción por defecto Seleccione...
    optionDefault.value = '';
    optionDefault.textContent = 'Seleccione...';
    censistasSelect.appendChild(optionDefault);
    // Crea las opciones para cada censista disponible utilizando un bucle for
    for (let i = 0; i < censistas.length; i++) {
        let censista = censistas[i];
        if (censista.nombre !== usuarioActivo) {
            let option = document.createElement('option');
            option.value = censista.nombre;
            option.textContent = censista.nombre;
            censistasSelect.appendChild(option);
        }
    }
}
// Event listener para el botón de reasignar
document.querySelector('#btnReasignar').addEventListener('click', reasignarCensista)
function reasignarCensista() {
    if (usuarioActivo === "") {
        alert("Debe Ingresar con su Nombre, Usuario y Contraseña primero.");
        return false;
    }
    if (personasPendientesSelect.value === "") {
        alert("Seleccione una persona Pendiente de Validar")
        return false
    }
    if (censistasSelect.value === "") {
        alert("Seleccione un Censista")
        return false
    }
    let cedulaSeleccionada = personasPendientesSelect.value;
    let censistaSeleccionado = censistasSelect.value;
    let personaSeleccionada = personas.find(function (persona) {
        return persona.cedula === cedulaSeleccionada;
    });
    if (personaSeleccionada.censista === censistaSeleccionado) {
        alert("El censista ya esta asignado a este usuario.")
    } else if (personaSeleccionada) {
        personaSeleccionada.censista = censistaSeleccionado;
        alert(`Se ha reasignado a ${personaSeleccionada.nombre} ${personaSeleccionada.apellido} al censista ${censistaSeleccionado}.`);
        cargarPersonasPendientes();
        cargarCensistasDisponibles();
    }
};
cargarPersonasPendientes();// Llama a las funciones para cargar las opciones de Pendientes y Censistas
cargarCensistasDisponibles();






//---------------------------VISUALIZAR INFORMACION ESTADISTICA------------------------------------------------------
let totalCensadas = 0;
let totalDepartamentos = {};
let totalPendientes = 0;
let totalPersonas = 0;
let totalMenores = 0;
let totalMayores = 0;
let porcentajeMenores = 0;
let porcentajeMayores = 0;
function cargarDepartamentos1() {
    let departamentoSelect = document.querySelector("#txtDepartamento");
    let optionDefault = document.createElement('option');
    optionDefault.value = '';
    optionDefault.textContent = 'Seleccione...';
    departamentoSelect.appendChild(optionDefault);
    for (let i = 0; i < departamentos.length; i++) {
        let departamento = departamentos[i];
        let option = document.createElement("option");
        option.value = departamento;
        option.textContent = departamento;
        departamentoSelect.appendChild(option);
    }
}
// Llamar a la función para precargar los departamentos en el select
cargarDepartamentos1();
function visualizarInformacion() {
    totalPersonas = 0;
    totalCensadas = 0;
    totalDepartamentos = {};
    totalPendientes = 0;
    // Reiniciar los contadores
    document.querySelector("#txtCensadasMomento").textContent = "";
    document.querySelector("#txtCensadasDepartamento").innerHTML = "";
    document.querySelector("#txtPendientes").textContent = "";
    // Calcular la cantidad de personas censadas para cada departamento
    for (let i = 0; i < personas.length; i++) {
        totalPersonas++;
        if (personas[i].censado === true) {
            totalCensadas++;
            if (totalDepartamentos[personas[i].departamento]) {
                totalDepartamentos[personas[i].departamento]++;
            } else {
                totalDepartamentos[personas[i].departamento] = 1;
            }
        } else {
            totalPendientes++;
        }
    }
    let porcentajePendientes = (totalPendientes / totalPersonas) * 100;
    // Mostrar la información estadística en el HTML
    document.querySelector("#txtCensadasMomento").textContent = totalCensadas;
    let censadasDepartamentoHTML = "";
    for (const departamento in totalDepartamentos) {
        censadasDepartamentoHTML += "<li>" + departamento + ": " + totalDepartamentos[departamento] + "</li>";
    }
    document.querySelector("#txtCensadasDepartamento").innerHTML = censadasDepartamentoHTML;
    document.querySelector("#txtPendientes").textContent = porcentajePendientes.toFixed(2) + "%";
}
// Función para mostrar el porcentaje de personas censadas menores y mayores de edad
function mostrarPorcentajeEdad() {
    let departamento = document.querySelector("#txtDepartamento").value;
    if (departamento === '') {
        alert("Seleccione un Departamento")
        return false
    }
    let totalMenoresCensados = 0;
    let totalMayoresCensados = 0;
    let totalMayoresNoCensados = 0;
    let totalMenoresNoCensados = 0;
    let totalMenores = 0;
    let totalMayores = 0;
    let porcentajeMenores = 0;
    let porcentajeMayores = 0;
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].departamento === departamento) {
            if (personas[i].censado === true) {
                if (personas[i].edad < 18) {
                    totalMenoresCensados++;
                } else {
                    totalMayoresCensados++;
                }
            } else {
                if (personas[i].edad < 18) {
                    totalMenoresNoCensados++;
                } else {
                    totalMayoresNoCensados++;
                }
            }
        }
    }
    totalMenores = totalMenoresCensados + totalMenoresNoCensados;
    totalMayores = totalMayoresCensados + totalMayoresNoCensados;
    if (totalMenores !== 0) {
        porcentajeMenores = (totalMenoresCensados / totalMenores) * 100;
    }
    if (totalMayores !== 0) {
        porcentajeMayores = (totalMayoresCensados / totalMayores) * 100;
    }
    document.querySelector("#txtPorcentajeMenores").textContent = porcentajeMenores.toFixed(2) + "%";
    document.querySelector("#txtPorcentajeMayores").textContent = porcentajeMayores.toFixed(2) + "%";
    // Reiniciar los contadores
    totalMenoresCensados = 0;
    totalMayoresCensados = 0;
    totalMayoresNoCensados = 0;
    totalMenoresNoCensados = 0;
}
// Asignar los eventos a los elementos correspondientes
document.querySelector("#btnVisualizarInformacion").addEventListener("click", visualizarInformacion);
document.querySelector("#btnMostrarPorcentajeEdad").addEventListener("click", mostrarPorcentajeEdad);
cargarDepartamentos();