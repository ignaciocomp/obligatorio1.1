//--------------------SISTEMA FUNCIONES-----------------------------------

let botones = document.querySelectorAll(".btn");
function ocultarSecciones() {
    let secciones = document.querySelectorAll(".seccion");
    for (let i = 0; i < secciones.length; i++) {
        const seccion = secciones[i];
        seccion.style.display = "none";
    }
}
for (let i = 0; i < botones.length; i++) {
    const boton = botones[i];
    boton.addEventListener("click", mostrarSeccion);
}
function mostrarSeccion() {
    let idBoton = this.getAttribute("id");//"btnSeccionVender"
    let idSeccion = idBoton.charAt(3).toLowerCase() + idBoton.substring(4) //"seccionVender" 
    cambiarSeccion(idSeccion);

}
function cambiarSeccion(nuevaSeccion) {
    ocultarSecciones();
    document.querySelector("#" + nuevaSeccion).style.display = "block";
}
function AgregarSeccion(nuevaSeccion) {

    document.querySelector("#" + nuevaSeccion).style.display = "block";
}
function mostrarBotones(tipo) {
    let botones = document.querySelectorAll(".btn");
    for (let i = 0; i < botones.length; i++) {
        const boton = botones[i];
        boton.style.display = "none";
    }

    let botonesMostrar = document.querySelectorAll("." + tipo);
    for (let i = 0; i < botonesMostrar.length; i++) {
        const botonMostrar = botonesMostrar[i];
        botonMostrar.style.display = "block";
    }
}
document.querySelector("#btnSalir").addEventListener("click", censista)
function salir() {
    cambiarSeccion("seccionRegistroCensistas")
    usuarioActivo = ""
    document.querySelector("#btnSeccionIngresarCensista").removeAttribute("hidden")
    document.querySelector("#btnSeccionRegistroCensistas").removeAttribute("hidden")
    document.querySelector("#btnSeccionIngresarDatos").removeAttribute("hidden")
    document.querySelector("#btnSeccionVerificarDatos").removeAttribute("hidden")
    document.querySelector("#btnSeccionReasignarPersona").removeAttribute("hidden")
    document.querySelector("#btnSeccionVisualizarInformacion").removeAttribute("hidden")
    document.querySelector("#txtPerfilInvitado").setAttribute("hidden", "true")
    document.querySelector("#txtPerfilCensista").removeAttribute("hidden")
    document.querySelector("#btnSeccionIngresarDatosInvitado").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionEliminarDatosInvitado").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionListaDeCensadosInvitado").setAttribute("hidden", "true")
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    document.querySelector("#btnUsuarioCensistaActivo").innerHTML = "Censista"
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    document.querySelector("#btnUsuarioCensistaActivo").innerHTML = "Censista"
}
function invitado() {
    document.querySelector("#txtCedulaInvitado1").value = ''
    document.querySelector("#txtCedulaEliminar").value = ''
    document.querySelector("#txtNombre1").value = '';
    document.querySelector("#txtUsuario1").value = '';
    document.querySelector("#txtContraseña1").value = '';
    document.querySelector('#txtUsuario2').value = ""
    document.querySelector('#txtContraseña2').value = ""
    document.querySelector("#txtNombre3").value = "";
    document.querySelector("#txtApellido3").value = "";
    document.querySelector("#txtEdad3").value = "";
    cedulaInput.value = "";
    departamentoSelect.value = "";
    ocupacionSelect.value = "";
    document.querySelector("#txtCensadasMomento").textContent = "";
    document.querySelector("#txtCensadasDepartamento").innerHTML = "";
    document.querySelector("#txtPendientes").textContent = "";
    document.querySelector("#txtDepartamento").value = ''
    document.querySelector("#txtCedula4").value = ''
    document.querySelector("#txtPorcentajeMenores").textContent = ''
    document.querySelector("#txtPorcentajeMayores").textContent = ''

    cambiarSeccion("seccionIngresarDatosInvitado")
    usuarioActivo = "invitado"
    document.querySelector("#btnSeccionIngresarCensista").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionRegistroCensistas").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionIngresarDatos").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionVerificarDatos").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionReasignarPersona").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionVisualizarInformacion").setAttribute("hidden", "true")
    document.querySelector("#txtPerfilCensista").setAttribute("hidden", "true")

    document.querySelector("#txtPerfilInvitado").removeAttribute("hidden")
    document.querySelector("#btnSeccionIngresarDatosInvitado").removeAttribute("hidden")
    document.querySelector("#btnSeccionEliminarDatosInvitado").removeAttribute("hidden")
    document.querySelector("#btnSeccionListaDeCensadosInvitado").removeAttribute("hidden")

    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    document.querySelector("#btnUsuarioCensistaActivo").innerHTML = "Censista"
}
document.querySelector("#btnUsuarioCensistaActivo").addEventListener("click", censista)
function censista() {
    document.querySelector("#txtCedulaInvitado1").value = ''
    document.querySelector("#txtCedulaEliminar").value = ''
    document.querySelector("#txtNombre1").value = '';
    document.querySelector("#txtUsuario1").value = '';
    document.querySelector("#txtContraseña1").value = '';
    document.querySelector('#txtUsuario2').value = ""
    document.querySelector('#txtContraseña2').value = ""
    document.querySelector("#txtNombre3").value = "";
    document.querySelector("#txtApellido3").value = "";
    document.querySelector("#txtEdad3").value = "";
    cedulaInput.value = "";
    departamentoSelect.value = "";
    ocupacionSelect.value = "";
    document.querySelector("#txtCensadasMomento").textContent = "";
    document.querySelector("#txtCensadasDepartamento").innerHTML = "";
    document.querySelector("#txtPendientes").textContent = "";
    document.querySelector("#txtDepartamento").value = ''
    document.querySelector("#txtCedula4").value = ''
    document.querySelector("#txtPorcentajeMenores").textContent = ''
    document.querySelector("#txtPorcentajeMayores").textContent = ''

    document.querySelector("#divCensado").removeAttribute("hidden");
    document.querySelector("#txtCedula3").removeAttribute("disabled");
    cambiarSeccion("seccionRegistroCensistas")
    usuarioActivo = ""
    document.querySelector("#btnAgregar").removeAttribute("hidden")
    document.querySelector("#btnAgregarInvitado").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionIngresarCensista").removeAttribute("hidden")
    document.querySelector("#btnSeccionRegistroCensistas").removeAttribute("hidden")
    document.querySelector("#btnSeccionIngresarDatos").removeAttribute("hidden")
    document.querySelector("#btnSeccionVerificarDatos").removeAttribute("hidden")
    document.querySelector("#btnSeccionReasignarPersona").removeAttribute("hidden")
    document.querySelector("#btnSeccionVisualizarInformacion").removeAttribute("hidden")
    document.querySelector("#txtPerfilInvitado").setAttribute("hidden", "true")

    document.querySelector("#txtPerfilCensista").removeAttribute("hidden")
    document.querySelector("#btnSeccionIngresarDatosInvitado").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionEliminarDatosInvitado").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionListaDeCensadosInvitado").setAttribute("hidden", "true")

    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    document.querySelector("#btnUsuarioCensistaActivo").innerHTML = "Censista"
}
cambiarSeccion("seccionRegistroCensistas");
document.querySelector("#btnSeccionIngresarDatosInvitado").setAttribute("hidden", "true")
document.querySelector("#btnSeccionEliminarDatosInvitado").setAttribute("hidden", "true")
document.querySelector("#btnSeccionListaDeCensadosInvitado").setAttribute("hidden", "true")
document.querySelector("#txtPerfilInvitado").setAttribute("hidden", "true")
document.querySelector("#btnInvitado").addEventListener("click", invitado)