function ocultarSecciones() {
    let secciones = document.querySelectorAll(".seccion");
    for (let i = 0; i < secciones.length; i++) {
        const seccion = secciones[i];
        seccion.style.display = "none";
    }
}

let botones = document.querySelectorAll(".btn");
for (let i = 0; i < botones.length; i++) {
    const boton = botones[i];
    boton.addEventListener("click", mostrarSeccion);
}

function mostrarSeccion() {
    let idBoton = this.getAttribute("id");//"btnSeccionVender"
    let idSeccion = idBoton.charAt(3).toLowerCase() + idBoton.substring(4) //"seccionVender" 
    cambiarSeccion(idSeccion);

}

function cambiarSeccion(nuevaSeccion) {
    ocultarSecciones();
    document.querySelector("#" + nuevaSeccion).style.display = "block";
}
function AgregarSeccion(nuevaSeccion) {

    document.querySelector("#" + nuevaSeccion).style.display = "block";
}

cambiarSeccion("seccionRegistroCensistas");

//mostrarBotones("inicio");

function mostrarBotones(tipo) {
    let botones = document.querySelectorAll(".btn");
    for (let i = 0; i < botones.length; i++) {
        const boton = botones[i];
        boton.style.display = "none";
    }

    let botonesMostrar = document.querySelectorAll("." + tipo);
    for (let i = 0; i < botonesMostrar.length; i++) {
        const botonMostrar = botonesMostrar[i];
        botonMostrar.style.display = "block";
    }
}



document.querySelector("#btnSalir").addEventListener("click", salir)
function salir() {
    cambiarSeccion("seccionRegistroCensistas")
    usuarioActivo = ""
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    document.querySelector("#btnUsuarioCensistaActivo").innerHTML = "Censista"
}

document.querySelector("#btnSeccionIngresarDatosInvitado").setAttribute("hidden", "true")
document.querySelector("#btnSeccionEliminarDatosInvitado").setAttribute("hidden", "true")
document.querySelector("#btnSeccionListaDeCensadosInvitado").setAttribute("hidden", "true")
document.querySelector("#txtPerfilInvitado").setAttribute("hidden", "true")



document.querySelector("#btnInvitado").addEventListener("click", invitado)
function invitado() {
    cambiarSeccion("seccionIngresarDatosInvitado")
    usuarioActivo = "invitado"
    document.querySelector("#btnSeccionIngresarCensista").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionRegistroCensistas").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionIngresarDatos").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionVerificarDatos").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionReasignarPersona").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionVisualizarInformacion").setAttribute("hidden", "true")
    document.querySelector("#txtPerfilCensista").setAttribute("hidden", "true")

    document.querySelector("#txtPerfilInvitado").removeAttribute("hidden")
    document.querySelector("#btnSeccionIngresarDatosInvitado").removeAttribute("hidden")
    document.querySelector("#btnSeccionEliminarDatosInvitado").removeAttribute("hidden")
    document.querySelector("#btnSeccionListaDeCensadosInvitado").removeAttribute("hidden")

    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    document.querySelector("#btnUsuarioCensistaActivo").innerHTML = "Censista"
}



document.querySelector("#btnUsuarioCensistaActivo").addEventListener("click", censista)
function censista() {
    document.querySelector("#divCensado").removeAttribute("hidden");
    cambiarSeccion("seccionRegistroCensistas")
    usuarioActivo = ""
    document.querySelector("#btnSeccionIngresarCensista").removeAttribute("hidden")
    document.querySelector("#btnSeccionRegistroCensistas").removeAttribute("hidden")
    document.querySelector("#btnSeccionIngresarDatos").removeAttribute("hidden")
    document.querySelector("#btnSeccionVerificarDatos").removeAttribute("hidden")
    document.querySelector("#btnSeccionReasignarPersona").removeAttribute("hidden")
    document.querySelector("#btnSeccionVisualizarInformacion").removeAttribute("hidden")
    document.querySelector("#txtPerfilInvitado").setAttribute("hidden", "true")

    document.querySelector("#txtPerfilCensista").removeAttribute("hidden")
    document.querySelector("#btnSeccionIngresarDatosInvitado").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionEliminarDatosInvitado").setAttribute("hidden", "true")
    document.querySelector("#btnSeccionListaDeCensadosInvitado").setAttribute("hidden", "true")

    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    document.querySelector("#btnUsuarioCensistaActivo").innerHTML = "Censista"
}



//-----------------------------------------------------------

//111111111111111111111111111111111111111111111111111111111
//CLASE CENSISTA CREADA
class Censista {
    constructor(nombre, usuario, contraseña) {
        this.nombre = nombre.toLowerCase();
        this.usuario = usuario.toLowerCase();
        this.contraseña = contraseña;
    }

    validarCredenciales(usuario, contraseña) {
        return (
            this.usuario === usuario.toLowerCase() && this.contraseña === contraseña);
    }
}
//ARRAYS 1
const usuariosCreados = [];

//FUNCIONES 1
//ACA CREE UNA FUNCION DONDE RECORRE TODAS LAS POS DEL ARRAY Y SI === usuario del campo de texto te tira falso sino true
function verificarNombreUsuarioUnico(usuario) {
    for (let i = 0; i < usuariosCreados.length; i++) {
        if (usuariosCreados[i].usuario === usuario) {
            return false;
        }
    }
    return true;
}
//aca cree una funcion y declare 3 variables may min num y las puse en false, desp un for q recorre todo el lenght de la contrasenia, y puse char === la pos del a contrasenia
//usando el ascii puse q si char === a z A Z y 0 9 devuelva true en min may num uno por uno y alfinal si todo esta true lo returnea
function verificarContraseñaValida(contraseña) {
    let tieneMinusc = false;
    let tieneMayusc = false;
    let tieneNumero = false;
    for (let i = 0; i < contraseña.length; i++) {
        let char = contraseña[i];
        if (char >= 'a' && char <= 'z') {
            tieneMinusc = true;
        } else if (char >= 'A' && char <= 'Z') {
            tieneMayusc = true;
        } else if (char >= '0' && char <= '9') {
            tieneNumero = true;
        }
    }
    //SI TODO ES TRUE LO RETURNEA
    return tieneMinusc && tieneMayusc && tieneNumero && contraseña.length >= 5;
}
// funcion para registrar al censista con 3 parametros,
//si la funcion de verificarusuario es false ! entonces te da mensaje de error
//lo mismo con verificar Contrasenia
//desp cera un nuevoCensista usando la clase y lo pushea al array usuariosCreados
function registrarCensista(nombre, usuario, contraseña) {
    if (!verificarNombreUsuarioUnico(usuario)) {
        alert("El nombre de usuario ya está en uso. Por favor, elige otro.");
        return;
    }
    if (!verificarContraseñaValida(contraseña)) {
        alert("La contraseña no cumple con los requisitos mínimos.");
        return;
    }
    let nuevoCensista = new Censista(nombre, usuario, contraseña);
    censistas.push(nuevoCensista)
    usuariosCreados.push(nuevoCensista);
    alert("Censista registrado con éxito.");
    document.querySelector("#txtNombre1").value = '';
    document.querySelector("#txtUsuario1").value = '';
    document.querySelector("#txtContraseña1").value = '';
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
}

function tomarValores1() {
    let nombre = document.querySelector("#txtNombre1").value;
    let usuario = document.querySelector("#txtUsuario1").value;
    let contraseña = document.querySelector("#txtContraseña1").value;

    //aca se verifica que los campos no esten vacios y si los estan, te tira un alert para q los llenes
    if (nombre.trim() === '') {
        alert("El campo de nombre es obligatorio.");
        return;
    }

    if (usuario.trim() === '') {
        alert("El campo de usuario es obligatorio.");
        return;
    }

    if (contraseña.trim() === '') {
        alert("El campo de contraseña es obligatorio.");
        return;
    }


    if (contraseña.length < 5) {
        alert("La contraseña debe tener al menos 5 caracteres.");
        return;
    }

    let tieneMinusc = false;
    let tieneMayusc = false;
    let tieneNumero = false;

    for (let i = 0; i < contraseña.length; i++) {
        const char = contraseña[i];

        if (char >= 'a' && char <= 'z') {
            tieneMinusc = true;
        } else if (char >= 'A' && char <= 'Z') {
            tieneMayusc = true;
        } else if (char >= '0' && char <= '9') {
            tieneNumero = true;
        }
    }

    if (!tieneMinusc) {
        alert("La contraseña debe contener al menos una letra minúscula.");
        return;
    }

    if (!tieneMayusc) {
        alert("La contraseña debe contener al menos una letra mayúscula.");
        return;
    }

    if (!tieneNumero) {
        alert("La contraseña debe contener al menos un número.");
        return;
    }

    registrarCensista(nombre, usuario, contraseña);
}

//Este boton toma los valores del campo de texto y ejecuta la funcion registrarCensista que tiene ejecuta otras funciones tambien
//tambien chequea de que la contrasenia tenga los requerimientos obligatorios
document.querySelector("#btnRegistrar").addEventListener("click", tomarValores1);
//1111111111111111111111111111111111111111111111111111111111111






let usuarioActivo = ""
//2222222222222222222222222222222222222222222222222222222222222222
// CREO UN ARARY DE CENSISTAS CON 3 USUARIOS PRE CARGADOS
let censistas = [
];
//AL HACER CLICK TOMA VALORES DE CAMPO
document.querySelector('#btnIngresar').addEventListener('click', function () {
    let usuario = document.querySelector('#txtUsuario2').value;
    let contraseña = document.querySelector('#txtContraseña2').value;
    // ACA DECLARA censitaValido como NULL y PASA POR LA FUNCION DE VALIDARCREDENCIALES, SI LAS CREDENCIALES QUE PUSISTE ESTAN EN EL ARRAY DE CENSISTAS, SE AGREGA A la variable CensistaVALIDO
    let censistaValido = null;
    for (let i = 0; i < censistas.length; i++) {
        let censista = censistas[i];
        if (censista.validarCredenciales(usuario, contraseña)) {
            censistaValido = censista;
            break;
        }
    }
    //SI CENSISTA ES VALIDO TE MANDA A LA PAGINA INGRESAR DATOS SINO TE DICE DA ERROR
    if (censistaValido) {
        // Credenciales correctas
        usuarioActivo = censistaValido.nombre;
        document.querySelector("#btnUsuarioCensistaActivo").innerHTML = ""
        document.querySelector("#btnUsuarioCensistaActivo").innerHTML = "Usuario Activo: " + usuarioActivo
        cambiarSeccion("seccionIngresarDatos")
        cargarPersonasPendientes();
        cargarCensistasDisponibles();

    } else {
        // Credenciales incorrectas
        alert('Credenciales incorrectas. Por favor, verifícalas.');
    }
    document.querySelector('#txtUsuario2').value = ""
    document.querySelector('#txtContraseña2').value = ""
});
//2222222222222222222222222222222222222222222222222222222222222222



//3333333333333333333333333333333333333333333333333333333333333333
console.log("escribiendo: personas muestra el array de objetos de la clase personas, escribiendo cedulasCensadas muestra array de cedulas, DESP BORRA ESTO")
//CREE CLASE PARA CADA PERSONA QUE SE QUIERA CENSAR
class Persona {
    constructor(nombre, apellido, edad, cedula, departamento, ocupacion, censado, censista) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.cedula = cedula;
        this.departamento = departamento;
        this.ocupacion = ocupacion;
        this.censado = censado;
        this.censista = censista;
    }
}
//Declaro variables de los Selec para mas adelante
let departamentoSelect = document.querySelector("#txtDepartamento3");
let cedulaInput = document.querySelector("#txtCedula3");
let ocupacionSelect = document.querySelector("#txtOcupacion3");
let censadoSelect = document.querySelector('#txtCensado3')
//Declaro arrays global de cedulas y el de la clase personas
let cedulasCensadas = ["1234"];

let departamentos = [
    "Artigas",
    "Canelones",
    "Cerro Largo",
    "Colonia",
    "Durazno",
    "Flores",
    "Florida",
    "Lavalleja",
    "Maldonado",
    "Montevideo",
    "Paysandú",
    "Río Negro",
    "Rivera",
    "Rocha",
    "Salto",
    "San José",
    "Soriano",
    "Tacuarembó",
    "Treinta y Tres"
];
//un pequeño array con los departamentos jaja
function cargarDepartamentos() {
    //recorre el array de departamentos y los carga dinamicamente en el option del HTML
    //asi podes evitar tener que escribir manualmente cada opción en el HTML y te deja modificar/agregar los departamentos en el array, sin tener que tocar el HTML
    for (let i = 0; i < departamentos.length; i++) {
        let departamento = departamentos[i];
        let option = document.createElement("option");
        option.value = departamento;
        option.textContent = departamento; // text content seria como InnerHTML pero en este escenario seria mas adecuado, sino tendriamos q escribir todo el HTML en el js
        departamentoSelect.appendChild(option); //se inserta el elemento option como una nueva opción dentro del menú desplegable, y se repite hasta terminar el bucle
    }
}

function validarCedula(cedula) {
    return true; // Lógica de validación de cédula
}

function esCedulaDuplicada(cedula) {
    return cedulasCensadas.includes(cedula);//si la cedula ingresada inculdes CEDULA entonces es que la cedula ya existe
}
// a continuacion, hice el mejor verificador de todos los tiempos
//verifica si algun campo quedo vacio, si ninguna cedula ya fue ingresada y si alguna cedula no es valida 
function validarFormulario() {
    let nombre = document.querySelector("#txtNombre3").value.trim();// ELIMINA ESPACIOS EN BLANCO AL PRINCIPIO Y FINAL
    let apellido = document.querySelector("#txtApellido3").value.trim();// ELIMINA ESPACIOS EN BLANCO AL PRINCIPIO Y FINAL
    let edad = document.querySelector("#txtEdad3").value;
    let cedula = cedulaInput.value.replace(/[^0-9]/g, "");//remueve puntos guiones espacios letras TODO lo q no sea numeros lo remueve
    let departamento = departamentoSelect.value;
    let ocupacion = ocupacionSelect.value;
    let censado = censadoSelect.value;

    //verifica si algun campo quedo vacio
    if (usuarioActivo === "invitado") {

    } else if (usuarioActivo === "") {
        alert("Debe Ingresar con su Nombre, Usuario y Contraseña primero.");
        return false;
    }

    if (nombre === "") {
        alert("El nombre no puede estar vacío.");
        return false;
    }

    if (apellido === "") {
        alert("El apellido no puede estar vacío.");
        return false;
    }

    if (edad === "") {
        alert("La edad no puede estar vacía.");
        return false;
    }
    if (!(edad > 0 && edad < 130)) {
        alert("La edad es Incorrecta.");
        return false;
    }

    if (cedula === "") {
        alert("La cédula no puede estar vacía.");
        return false;
    }

    if (departamento === "") {
        alert("Debe seleccionar un departamento de residencia.");
        return false;
    }

    if (ocupacion === "") {
        alert("Debe seleccionar una ocupación.");
        return false;
    }
    //verifica si la cedula ya esta censada
    if (esCedulaDuplicada(cedula)) {
        alert("Ya existe una persona censada para esta cédula.");
        return false;
    }
    //verifica si la cedula es valida
    if (!validarCedula(cedula)) {
        alert("La cédula ingresada no es válida.");
        return false;
    }
    if (censado === "") {
        alert("El campo Censado no puede quedar vacio")
        return false;
    }

    return true; // si pasa todas las verificaciones returnea TRUE, sino returnea false y tira alert
}


//ejecuto funcion para cargar los departamentos
cargarDepartamentos();

//al hacer click GUARDAR ejecuta la gran funcion validarFormulario(), si devuelve true, crea el objeto Persona y 
//lo agrega al array de personas, y tambien guarda la cedula en el array de cedulasCensadas
document.querySelector("#btnAgregar").addEventListener("click", function () {
    if (validarFormulario()) {
        let nombre = document.querySelector("#txtNombre3").value.trim();
        let apellido = document.querySelector("#txtApellido3").value.trim();
        let edad = document.querySelector("#txtEdad3").value;
        let cedula = cedulaInput.value.replace(/[^0-9]/g, "");
        let departamento = departamentoSelect.value;
        let ocupacion = ocupacionSelect.value;
        const censadoSelect = document.querySelector('#txtCensado3');
        const censadoValue = censadoSelect.value === "true"; // Convertir a booleano

        //let censista = USUARIO QUE LOGEASTE COMO CENSISTA
        const persona = new Persona(nombre, apellido, edad, cedula, departamento, ocupacion, censadoValue, usuarioActivo);;//crea el objeto nuevo Persona
        // if (censadoSelect.value === "false") {
        //     persona.censado = false
        // }
        personas.push(persona); // pushea al array de personas


        cedulasCensadas.push(cedula);// pushea al array de cedulas

        //mando un mensaje de notificacion con todos los datos que se cargaron al array de personas
        alert(`Datos válidos, se pueden guardar.
        Nombre: ${persona.nombre}
        Apellido: ${persona.apellido}
        Edad: ${persona.edad}
        Cédula: ${persona.cedula}
        Departamento: ${persona.departamento}
        Ocupación: ${persona.ocupacion}`);
        //resetea los campos de texto nuevamente para volver a ingresar nuevos textos
        document.querySelector("#txtNombre3").value = "";
        document.querySelector("#txtApellido3").value = "";
        document.querySelector("#txtEdad3").value = "";
        cedulaInput.value = "";
        departamentoSelect.value = "";
        ocupacionSelect.value = "";
    }
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
});


//3333333333333333333333333333333333333333333333333333333333333333






//4444444444444444444444444444444444444444444444444444444444444444
document.querySelector("#btnVerificar").addEventListener('click', verificarDatos);
let verificar = []
function verificarDatos() {
    verificar.splice(0, verificar.length)
    let cedula = document.querySelector('#txtCedula4').value;
    let personaEncontrada = null;

    if (cedula === "") {
        alert("El campo no puede estar vacío");
        return false;
    }

    for (let i = 0; i < personas.length; i++) {
        if (personas[i].cedula === cedula) {
            if (personas[i].censado === true) {
                document.querySelector('#pVerificar').innerHTML = 'La cédula ya está Censada.';
                return false;
            } else {
                personaEncontrada = personas[i];
                break;
            }
        }
    }


    if (personaEncontrada) {
        AgregarSeccion("seccionIngresarDatos");
        document.querySelector("#btnConfirmar").removeAttribute("hidden");
        document.querySelector("#btnAgregar").setAttribute("hidden", "true");
        document.querySelector('#txtNombre3').value = personaEncontrada.nombre;
        document.querySelector('#txtApellido3').value = personaEncontrada.apellido;
        document.querySelector('#txtEdad3').value = personaEncontrada.edad;
        document.querySelector("#txtCedula3").value = personaEncontrada.cedula;
        document.querySelector('#txtDepartamento3').value = personaEncontrada.departamento;
        document.querySelector('#txtOcupacion3').value = personaEncontrada.ocupacion;
        document.querySelector('#txtCensado3').value = personaEncontrada.censado.toString();
    } else {
        document.querySelector('#pVerificar').innerHTML = 'La cédula no fue encontrada.';
    }
    verificar.push(personaEncontrada)
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
}

document.querySelector("#btnConfirmar").addEventListener("click", ValidarCenso);

function ValidarCenso() {
    if (censadoSelect.value === "true") {
        verificar[0].censado = true;
        alert("Usuario Validado");
        cambiarSeccion("seccionVerificarDatos")
    } else if (censadoSelect.value === "false") {
        verificar[0].censado = false;
    }
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    //resetea los campos de texto nuevamente para volver a ingresar nuevos textos
    document.querySelector("#txtNombre3").value = "";
    document.querySelector("#txtApellido3").value = "";
    document.querySelector("#txtEdad3").value = "";
    cedulaInput.value = "";
    departamentoSelect.value = "";
    ocupacionSelect.value = "";
}

//444444444444444444444444444444444444444444444444444444444444444444444



//55555555555555555555555555555555555555555555555555555555555555555555

let ocupaciones = [
    "Dependiente",
    "Independiente",
    "Estudiante",
    "No trabaja"
];

let censista1 = new Censista("Juan", "juancensista", "Contrasena1");
let censista2 = new Censista("María", "mariacensista", "Contrasena3");
let censista3 = new Censista("Pedro", "pedrocensista", "Contrasena3");










censistas.push(censista1, censista2, censista3);
let personas = [
    new Persona("John", "Doe", 44, "1234567890", departamentos[0], ocupaciones[0], false, censistas[0].nombre),
    new Persona("Jane", "Smith", 32, "0987654321", departamentos[1], ocupaciones[2], false, censistas[1].nombre),
    new Persona("George", "Elin", 77, "5678901234", departamentos[2], ocupaciones[1], false, censistas[2].nombre),
    new Persona("Emily", "Brown", 50, "4321098765", departamentos[3], ocupaciones[3], false, censistas[0].nombre),
    new Persona("Daniel", "Miller", 28, "9876543210", departamentos[4], ocupaciones[4], false, censistas[1].nombre),
    new Persona("Olivia", "Davis", 35, "3456789012", departamentos[5], ocupaciones[2], false, censistas[2].nombre),
    new Persona("David", "Wilson", 45, "2109876543", departamentos[6], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Sophia", "Moore", 55, "6543210987", departamentos[7], ocupaciones[3], false, censistas[1].nombre),
    new Persona("Emma", "Taylor", 30, "8765432109", departamentos[8], ocupaciones[4], false, censistas[2].nombre),
    new Persona("Noah", "Anderson", 38, "9012345678", departamentos[9], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Liam", "Wilson", 42, "7654321098", departamentos[10], ocupaciones[2], false, censistas[1].nombre),
    new Persona("Ava", "Johnson", 29, "2345678901", departamentos[11], ocupaciones[3], false, censistas[2].nombre),
    new Persona("Ethan", "Miller", 48, "6789012345", departamentos[12], ocupaciones[1], true, censistas[0].nombre),
    new Persona("Mia", "Davis", 36, "5432109876", departamentos[13], ocupaciones[4], true, censistas[1].nombre),
    new Persona("Isabella", "Moore", 31, "8901234567", departamentos[14], ocupaciones[2], true, censistas[2].nombre),
    new Persona("James", "Taylor", 39, "4567890123", departamentos[15], ocupaciones[3], true, censistas[0].nombre),
    new Persona("Benjamin", "Anderson", 43, "0123456789", departamentos[16], ocupaciones[1], true, censistas[1].nombre),
    new Persona("Luna", "Smith", 27, "3210987654", departamentos[17], ocupaciones[4], true, censistas[2].nombre),
    new Persona("Elijah", "Johnson", 33, "7890123456", departamentos[18], ocupaciones[2], true, censistas[0].nombre),
    new Persona("Scarlett", "Brown", 41, "2109876541", departamentos[0], ocupaciones[3], true, censistas[1].nombre),
    new Persona("Alejandro", "Vazquez", 17, "1111111111", departamentos[1], ocupaciones[1], true, censistas[2].nombre),
    new Persona("Sophia", "Young", 35, "2222222222", departamentos[2], ocupaciones[2], true, censistas[0].nombre),
    new Persona("JuanIgnacio", "Mendez", 28, "3333333333", departamentos[3], ocupaciones[3], true, censistas[1].nombre),
    new Persona("Charlotte", "Anderson", 41, "4444444444", departamentos[4], ocupaciones[4], false, censistas[2].nombre),
    new Persona("Ignacio", "Compan", 19, "5555555555", departamentos[5], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Amelia", "Brown", 12, "6666666666", departamentos[6], ocupaciones[0], true, censistas[1].nombre),
    new Persona("Benjamin", "Smith", 37, "7777777777", departamentos[7], ocupaciones[2], true, censistas[2].nombre),
    new Persona("Ava", "Taylor", 23, "8888888888", departamentos[8], ocupaciones[3], false, censistas[0].nombre),
    new Persona("Noah", "Davis", 31, "9999999999", departamentos[9], ocupaciones[4], false, censistas[1].nombre),
    new Persona("Jorge", "Carrion", 31, "9999999999", departamentos[10], ocupaciones[1], true, censistas[2].nombre),
];

// Obtén referencias a los elementos del DOM
let personasPendientesSelect = document.querySelector('#personas-pendientes');
let censistasSelect = document.querySelector('#censistas');
let btnReasignar = document.querySelector('#btnReasignar');

// Función para cargar las opciones de personas pendientes
function cargarPersonasPendientes() {
    // Limpia las opciones existentes
    personasPendientesSelect.innerHTML = '';

    // Crea la opción por defecto
    let optionDefault = document.createElement('option');
    optionDefault.value = '';
    optionDefault.textContent = 'Seleccione...';
    personasPendientesSelect.appendChild(optionDefault);

    for (let i = 0; i < personas.length; i++) {
        if (personas[i].censado === false) {
            let option = document.createElement('option');
            option.value = personas[i].cedula;
            option.textContent = `${personas[i].nombre} ${personas[i].apellido}, CENSISTA: ${personas[i].censista}`;
            personasPendientesSelect.appendChild(option);
        }
    }
}

// Función para cargar las opciones de censistas disponibles
function cargarCensistasDisponibles() {
    // Limpia las opciones existentes
    censistasSelect.innerHTML = '';

    // Crea la opción por defecto
    let optionDefault = document.createElement('option');
    optionDefault.value = '';
    optionDefault.textContent = 'Seleccione...';
    censistasSelect.appendChild(optionDefault);

    // Crea las opciones para cada censista disponible utilizando un bucle for
    for (let i = 0; i < censistas.length; i++) {
        let censista = censistas[i];
        if (censista.nombre !== usuarioActivo) {
            let option = document.createElement('option');
            option.value = censista.nombre;
            option.textContent = censista.nombre;
            censistasSelect.appendChild(option);
        }
    }


}

// Event listener para el botón de reasignar
btnReasignar.addEventListener('click', function () {
    // if (usuarioActivo === "") {
    //     alert("Debe Ingresar con su Nombre, Usuario y Contraseña primero.");
    //     return false;
    // }
    if (personasPendientesSelect.value === "") {
        alert("Seleccione una persona Pendiente de Validar")
        return false
    }
    if (censistasSelect.value === "") {
        alert("Seleccione un Censista")
        return false
    }
    let cedulaSeleccionada = personasPendientesSelect.value;
    let censistaSeleccionado = censistasSelect.value;

    let personaSeleccionada = personas.find(function (persona) {
        return persona.cedula === cedulaSeleccionada;
    });

    if (personaSeleccionada.censista === censistaSeleccionado) {
        alert("El censista ya esta asignado a este usuario.")
    } else if (personaSeleccionada) {
        personaSeleccionada.censista = censistaSeleccionado;
        alert(`Se ha reasignado a ${personaSeleccionada.nombre} ${personaSeleccionada.apellido} al censista ${censistaSeleccionado}.`);
        cargarPersonasPendientes();
        cargarCensistasDisponibles();
    }


});

// Llama a las funciones para cargar las opciones iniciales
cargarPersonasPendientes();
cargarCensistasDisponibles();

//5555555555555555555555555555555555555555555555555555555555555





//6666666666666666666666666666666666666666666666666666666666666666666666666666

let totalCensadas = 0;
let totalDepartamentos = {};
let totalPendientes = 0;
let totalPersonas = 0;
let totalMenores = 0;
let totalMayores = 0;
function cargarDepartamentos1() {



    let departamentoSelect = document.querySelector("#txtDepartamento");
    let optionDefault = document.createElement('option');
    optionDefault.value = '';
    optionDefault.textContent = 'Seleccione...';
    departamentoSelect.appendChild(optionDefault);

    for (let i = 0; i < departamentos.length; i++) {
        let departamento = departamentos[i];
        let option = document.createElement("option");
        option.value = departamento;
        option.textContent = departamento;
        departamentoSelect.appendChild(option);
    }

}

// Llamar a la función para precargar los departamentos en el select
cargarDepartamentos1();

function visualizarInformacion() {
    totalPersonas = 0;
    totalCensadas = 0;
    totalDepartamentos = {};
    totalPendientes = 0;

    // Reiniciar los contadores
    document.querySelector("#txtCensadasMomento").textContent = "";
    document.querySelector("#txtCensadasDepartamento").innerHTML = "";
    document.querySelector("#txtPendientes").textContent = "";

    // Calcular la cantidad de personas censadas para cada departamento
    for (let i = 0; i < personas.length; i++) {
        totalPersonas++;
        if (personas[i].censado === true) {
            totalCensadas++;
            if (totalDepartamentos[personas[i].departamento]) {
                totalDepartamentos[personas[i].departamento]++;
            } else {
                totalDepartamentos[personas[i].departamento] = 1;
            }
        } else {
            totalPendientes++;
        }
    }

    let porcentajePendientes = (totalPendientes / totalPersonas) * 100;

    // Mostrar la información estadística en el HTML
    document.querySelector("#txtCensadasMomento").textContent = totalCensadas;

    let censadasDepartamentoHTML = "";
    for (const departamento in totalDepartamentos) {
        censadasDepartamentoHTML += "<li>" + departamento + ": " + totalDepartamentos[departamento] + "</li>";
    }
    document.querySelector("#txtCensadasDepartamento").innerHTML = censadasDepartamentoHTML;

    document.querySelector("#txtPendientes").textContent = porcentajePendientes.toFixed(2) + "%";
}

// Función para mostrar el porcentaje de personas censadas menores y mayores de edad
function mostrarPorcentajeEdad() {
    let departamento = document.querySelector("#txtDepartamento").value;
    let totalMenoresCensados = 0;
    let totalMayoresCensados = 0;
    let totalMayoresNoCensados = 0;
    let totalMenoresNoCensados = 0;
    let totales = 0;

    for (let i = 0; i < personas.length; i++) {
        if (personas[i].departamento === departamento) {
            if (personas[i].censado === true) {
                if (personas[i].edad < 18) {
                    totalMenoresCensados++;
                } else {
                    totalMayoresCensados++;
                }
            } else {
                if (personas[i].edad < 18) {
                    totalMenoresNoCensados++;
                } else {
                    totalMayoresNoCensados++;
                }
            }
        }
    }

    let totalMenores = totalMenoresCensados + totalMenoresNoCensados;
    let totalMayores = totalMayoresCensados + totalMayoresNoCensados;

    let porcentajeMenores = (totalMenoresCensados / totalMenores) * 100;
    let porcentajeMayores = (totalMayoresCensados / totalMayores) * 100;

    document.querySelector("#txtPorcentajeMenores").textContent = porcentajeMenores.toFixed(2) + "%";
    document.querySelector("#txtPorcentajeMayores").textContent = porcentajeMayores.toFixed(2) + "%";

    // Reiniciar los contadores
    totalMenoresCensados = 0;
    totalMayoresCensados = 0;
    totalMayoresNoCensados = 0;
    totalMenoresNoCensados = 0;
    totales = 0;
}



// Asignar los eventos a los elementos correspondientes
document.querySelector("#btnVisualizarInformacion").addEventListener("click", visualizarInformacion);
document.querySelector("#btnMostrarPorcentajeEdad").addEventListener("click", mostrarPorcentajeEdad);

//6666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666






//PERFIL INVITADOOOOOOOOOOOOO






//----------------------------------------------------------
//111111111111111111111111111111111111111111111111

document.querySelector("#btnIngresarDatosInvitado").addEventListener("click", IngresarDatosInvitado)
function IngresarDatosInvitado() {
    AgregarSeccion("seccionIngresarDatos");
    document.querySelector("#divCensado").setAttribute("hidden", "true");
    document.querySelector("#btnAgregarInvitado").removeAttribute("hidden");
    document.querySelector("#btnAgregar").setAttribute("hidden", "true");
    document.querySelector("#btnConfirmar").setAttribute("hidden", "true");
}

let verificarInvitado = []
document.querySelector("#btnVerificarInvitado").addEventListener('click', verificarDatosInvitado);

function verificarDatosInvitado() {
    verificarInvitado.splice(0, verificarInvitado.length)
    let cedula = document.querySelector('#txtCedulaInvitado1').value;
    let personaEncontrada = null;
    if (cedula === "") {
        alert("El campo no puede estar vacío");
        return false;
    }
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].cedula === cedula) {
            if (personas[i].censado === true) {
                document.querySelector('#pMensajeInvitado').innerHTML = 'La cédula ya está Censada.';
                return false;
            } else {
                personaEncontrada = personas[i];
                break;
            }
        }
    }
    if (personaEncontrada) {
        AgregarSeccion("seccionIngresarDatos");
        document.querySelector("#divCensado").setAttribute("hidden", "true");
        document.querySelector("#btnAgregarInvitado").removeAttribute("hidden");
        document.querySelector("#btnAgregar").setAttribute("hidden", "true");
        document.querySelector("#btnConfirmar").setAttribute("hidden", "true");
        document.querySelector('#txtNombre3').value = personaEncontrada.nombre;
        document.querySelector('#txtApellido3').value = personaEncontrada.apellido;
        document.querySelector('#txtEdad3').value = personaEncontrada.edad;
        document.querySelector("#txtCedula3").value = personaEncontrada.cedula;
        document.querySelector('#txtDepartamento3').value = personaEncontrada.departamento;
        document.querySelector('#txtOcupacion3').value = personaEncontrada.ocupacion;
        document.querySelector('#txtCensado3').value = personaEncontrada.censado.toString();
    } else {
        document.querySelector('#pMensajeInvitado').innerHTML = 'La cédula no fue encontrada.';
    }
    verificarInvitado.push(personaEncontrada)
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
}



function asignarCensistaAleatorio() {
    const indiceAleatorio = Math.floor(Math.random() * censistas.length);
    const censistaAleatorio = censistas[indiceAleatorio].nombre;
    return censistaAleatorio;
}

document.querySelector("#btnAgregarInvitado").addEventListener("click", function () {
    if (validarFormulario()) {
        let nombre = document.querySelector("#txtNombre3").value.trim();
        let apellido = document.querySelector("#txtApellido3").value.trim();
        let edad = document.querySelector("#txtEdad3").value;
        let cedula = cedulaInput.value.replace(/[^0-9]/g, "");
        let departamento = departamentoSelect.value;
        let ocupacion = ocupacionSelect.value;
        const censadoSelect = document.querySelector('#txtCensado3');
        const censadoValue = censadoSelect.value === "true"; // Convertir a booleano
        let censista = asignarCensistaAleatorio()

        //let censista = USUARIO QUE LOGEASTE COMO CENSISTA
        const persona = new Persona(nombre, apellido, edad, cedula, departamento, ocupacion, censadoValue, censista);;//crea el objeto nuevo Persona
        // if (censadoSelect.value === "false") {
        //     persona.censado = false
        // }
        personas.push(persona); // pushea al array de personas


        cedulasCensadas.push(cedula);// pushea al array de cedulas

        //mando un mensaje de notificacion con todos los datos que se cargaron al array de personas
        alert(`Datos válidos, se pueden guardar.
        Nombre: ${persona.nombre}
        Apellido: ${persona.apellido}
        Edad: ${persona.edad}
        Cédula: ${persona.cedula}
        Departamento: ${persona.departamento}
        Ocupación: ${persona.ocupacion}
        Censista: ${persona.censista}`);
        //resetea los campos de texto nuevamente para volver a ingresar nuevos textos
        document.querySelector("#txtNombre3").value = "";
        document.querySelector("#txtApellido3").value = "";
        document.querySelector("#txtEdad3").value = "";
        cedulaInput.value = "";
        departamentoSelect.value = "";
        ocupacionSelect.value = "";
    }
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
});
//11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111





//222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222

document.querySelector("#btnBuscar").addEventListener('click', buscarDatos);

function buscarDatos() {
    let cedula = document.querySelector('#txtCedulaEliminar').value;
    let personaEncontrada = null;

    if (cedula === "") {
        alert("El campo no puede estar vacío");
        return false;
    }

    for (let i = 0; i < personas.length; i++) {
        if (personas[i].cedula === cedula) {
            if (personas[i].censado === true) {
                document.querySelector('#pMensajeEliminar').innerHTML = 'La cédula ya está Censada.';
                return false;
            } else {
                personaEncontrada = personas[i];
                break;
            }
        }
    }


    if (personaEncontrada) {
        let confirmacion = confirm(`Desea eliminar sus datos?
        Nombre: ${personaEncontrada.nombre}
        Apellido: ${personaEncontrada.apellido}
        Edad: ${personaEncontrada.edad}
        Cédula: ${personaEncontrada.cedula}
        Departamento: ${personaEncontrada.departamento}
        Ocupación: ${personaEncontrada.ocupacion}
        Censista: ${personaEncontrada.censista}`)
        if (confirmacion) {
            personas.splice(personaEncontrada, 1);
            document.querySelector('#pMensajeEliminar').innerHTML = `Datos Eliminados.`
        }
    } else {
        document.querySelector('#pMensajeEliminar').innerHTML = 'La cédula no fue encontrada.';
    }
}

//222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222

function registrarDatos(departamentoElegir) {
    let contadores = {
        Estudiantes: 0,
        NoTrabaja: 0,
        IndependienteDependiente: 0,
        Censado: 0,
        noCensado: 0,
        totales: 0,
        porcentaje: 0,
    };
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].departamento === departamentoElegir) {
            contadores.totales++
            if (personas[i].ocupacion === "Estudiante") {
                contadores.Estudiantes++
            }
            if (personas[i].ocupacion === "No trabaja") {
                contadores.NoTrabaja++
            }
            if (personas[i].ocupacion === "Dependiente" || personas[i].ocupacion === "Independiente") {
                contadores.IndependienteDependiente++
            }
            if (personas[i].censado) {
                contadores.Censado++
            } else {
                contadores.noCensado++
            }
        }
    }
    contadores.porcentaje = (contadores.Censado / contadores.totales) * 100
    return contadores;
}
//33333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333
document.querySelector("#btnSeccionListaDeCensadosInvitado").addEventListener("click", cargarTabla)

function cargarTabla() {
    var tabla = document.getElementById("tblListaCensados");
    var tbody = tabla.getElementsByTagName("tbody")[0];

    let Artigas = registrarDatos("Artigas")
    let Canelones = registrarDatos("Canelones")
    let CerroLargo = registrarDatos("Cerro Largo")
    let Durazno = registrarDatos("Durazno")
    let Flores = registrarDatos("Flores")
    let Florida = registrarDatos("Florida")
    let Lavalleja = registrarDatos("Lavalleja")
    let Maldonado = registrarDatos("Maldonado")
    let Montevideo = registrarDatos("Montevideo")
    let Paysandú = registrarDatos("Paysandú")
    let RíoNegro = registrarDatos("Río Negro")
    let Rivera = registrarDatos("Rivera")
    let Rocha = registrarDatos("Rocha")
    let Salto = registrarDatos("Salto")
    let SanJosé = registrarDatos("San José")
    let Soriano = registrarDatos("Soriano")
    let Tacuarembó = registrarDatos("Tacuarembó")
    let TreintayTres = registrarDatos("Treinta y Tres")

    const tbody1 = document.querySelector("#tblListaCensados tbody");
    tbody1.innerHTML = `
        <tr>
            <td>Artigas</td>
            <td>${Artigas.Estudiantes}</td>
            <td>${Artigas.NoTrabaja}</td>
            <td>${Artigas.IndependienteDependiente}</td>
            <td>${Artigas.porcentaje.toFixed(0)} %</td>
        </tr>
        <tr>
            <td>Canelones</td>
            <td>${Canelones.Estudiantes}</td>
            <td>${Canelones.NoTrabaja}</td>
            <td>${Canelones.IndependienteDependiente}</td>
            <td>${(Canelones.porcentaje.toFixed(0))} %</td>
        </tr>
        <tr>
            <td>CerroLargo</td>
            <td>${CerroLargo.Estudiantes}</td>
            <td>${CerroLargo.NoTrabaja}</td>
            <td>${CerroLargo.IndependienteDependiente}</td>
            <td>${(CerroLargo.porcentaje.toFixed(0))} %</td>
        </tr>
        <tr>
        <td>Durazno</td>
        <td>${Durazno.Estudiantes}</td>
        <td>${Durazno.NoTrabaja}</td>
        <td>${Durazno.IndependienteDependiente}</td>
        <td>${(Durazno.porcentaje.toFixed(0))} %</td>
        </tr>
        <tr>
        <td>Flores</td>
        <td>${Flores.Estudiantes}</td>
        <td>${Flores.NoTrabaja}</td>
        <td>${Flores.IndependienteDependiente}</td>
        <td>${(Flores.porcentaje.toFixed(0))} %</td>
        </tr>
        <tr>
        <td>Florida</td>
        <td>${Florida.Estudiantes}</td>
        <td>${Florida.NoTrabaja}</td>
        <td>${Florida.IndependienteDependiente}</td>
        <td>${(Florida.porcentaje.toFixed(0))} %</td>
        </tr>
        <tr>
        <td>Lavalleja</td>
        <td>${Lavalleja.Estudiantes}</td>
        <td>${Lavalleja.NoTrabaja}</td>
        <td>${Lavalleja.IndependienteDependiente}</td>
        <td>${((Lavalleja.porcentaje.toFixed(0)))} %</td>
        </tr>
        <tr>
        <td>Maldonado</td>
        <td>${Maldonado.Estudiantes}</td>
        <td>${Maldonado.NoTrabaja}</td>
        <td>${Maldonado.IndependienteDependiente}</td>
        <td>${(Maldonado.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Montevideo</td>
        <td>${Montevideo.Estudiantes}</td>
        <td>${Montevideo.NoTrabaja}</td>
        <td>${Montevideo.IndependienteDependiente}</td>
        <td>${(Montevideo.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Paysandú</td>
        <td>${Paysandú.Estudiantes}</td>
        <td>${Paysandú.NoTrabaja}</td>
        <td>${Paysandú.IndependienteDependiente}</td>
        <td>${(Paysandú.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>RìoNegro</td>
        <td>${RíoNegro.Estudiantes}</td>
        <td>${RíoNegro.NoTrabaja}</td>
        <td>${RíoNegro.IndependienteDependiente}</td>
        <td>${(RíoNegro.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Rivera</td>
        <td>${Rivera.Estudiantes}</td>
        <td>${Rivera.NoTrabaja}</td>
        <td>${Rivera.IndependienteDependiente}</td>
        <td>${(Rivera.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Rocha</td>
        <td>${Rocha.Estudiantes}</td>
        <td>${Rocha.NoTrabaja}</td>
        <td>${Rocha.IndependienteDependiente}</td>
        <td>${(Rocha.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Salto</td>
        <td>${Salto.Estudiantes}</td>
        <td>${Salto.NoTrabaja}</td>
        <td>${Salto.IndependienteDependiente}</td>
        <td>${(Salto.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>SanJosé</td>
        <td>${SanJosé.Estudiantes}</td>
        <td>${SanJosé.NoTrabaja}</td>
        <td>${SanJosé.IndependienteDependiente}</td>
        <td>${(SanJosé.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Soriano</td>
        <td>${Soriano.Estudiantes}</td>
        <td>${Soriano.NoTrabaja}</td>
        <td>${Soriano.IndependienteDependiente}</td>
        <td>${(Soriano.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Tacuarembó</td>
        <td>${Tacuarembó.Estudiantes}</td>
        <td>${Tacuarembó.NoTrabaja}</td>
        <td>${Tacuarembó.IndependienteDependiente}</td>
        <td>${(Tacuarembó.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>TreintayTres</td>
        <td>${TreintayTres.Estudiantes}</td>
        <td>${TreintayTres.NoTrabaja}</td>
        <td>${TreintayTres.IndependienteDependiente}</td>
        <td>${(TreintayTres.porcentaje.toFixed(0))} %</td>
        </tr>
        `;
}