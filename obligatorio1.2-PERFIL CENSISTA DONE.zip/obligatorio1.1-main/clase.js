function ocultarSecciones() {
    let secciones = document.querySelectorAll(".seccion");
    for (let i = 0; i < secciones.length; i++) {
        const seccion = secciones[i];
        seccion.style.display = "none";
    }
}

let botones = document.querySelectorAll(".btn");
for (let i = 0; i < botones.length; i++) {
    const boton = botones[i];
    boton.addEventListener("click", mostrarSeccion);
}

function mostrarSeccion() {
    let idBoton = this.getAttribute("id");//"btnSeccionVender"
    let idSeccion = idBoton.charAt(3).toLowerCase() + idBoton.substring(4) //"seccionVender" 
    cambiarSeccion(idSeccion);

}

function cambiarSeccion(nuevaSeccion) {
    ocultarSecciones();
    document.querySelector("#" + nuevaSeccion).style.display = "block";
}
function AgregarSeccion(nuevaSeccion) {

    document.querySelector("#" + nuevaSeccion).style.display = "block";
}

cambiarSeccion("seccionRegistroCensistas");

//mostrarBotones("inicio");

function mostrarBotones(tipo) {
    let botones = document.querySelectorAll(".btn");
    for (let i = 0; i < botones.length; i++) {
        const boton = botones[i];
        boton.style.display = "none";
    }

    let botonesMostrar = document.querySelectorAll("." + tipo);
    for (let i = 0; i < botonesMostrar.length; i++) {
        const botonMostrar = botonesMostrar[i];
        botonMostrar.style.display = "block";
    }
}



document.querySelector("#txtSalir").addEventListener("click", salir)
function salir() {
    cambiarSeccion("seccionRegistroCensistas")
    usuarioActivo = ""
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    document.querySelector("#txtUsuarioCensistaActivo").innerHTML = "Censista"
}

//-----------------------------------------------------------

//111111111111111111111111111111111111111111111111111111111
//CLASES 1
//CLASE CENSISTA CREADA
class Censista {
    constructor(nombre, usuario, contraseña) {
        this.nombre = nombre.toLowerCase();
        this.usuario = usuario.toLowerCase();
        this.contraseña = contraseña;
    }

    validarCredenciales(usuario, contraseña) {
        return (
            this.usuario === usuario.toLowerCase() && this.contraseña === contraseña);
    }
}
//ARRAYS 1
const usuariosCreados = [];

//FUNCIONES 1
//ACA CREE UNA FUNCION DONDE RECORRE TODAS LAS POS DEL ARRAY Y SI === usuario del campo de texto te tira falso sino true
function verificarNombreUsuarioUnico(usuario) {
    for (let i = 0; i < usuariosCreados.length; i++) {
        if (usuariosCreados[i].usuario === usuario) {
            return false;
        }
    }
    return true;
}
//aca cree una funcion y declare 3 variables may min num y las puse en false, desp un for q recorre todo el lenght de la contrasenia, y puse char === la pos del a contrasenia
//usando el ascii puse q si char === a z A Z y 0 9 devuelva true en min may num uno por uno y alfinal si todo esta true lo returnea
function verificarContraseñaValida(contraseña) {
    let tieneMinusc = false;
    let tieneMayusc = false;
    let tieneNumero = false;
    for (let i = 0; i < contraseña.length; i++) {
        let char = contraseña[i];
        if (char >= 'a' && char <= 'z') {
            tieneMinusc = true;
        } else if (char >= 'A' && char <= 'Z') {
            tieneMayusc = true;
        } else if (char >= '0' && char <= '9') {
            tieneNumero = true;
        }
    }
    //SI TODO ES TRUE LO RETURNEA
    return tieneMinusc && tieneMayusc && tieneNumero && contraseña.length >= 5;
}
// funcion para registrar al censista con 3 parametros,
//si la funcion de verificarusuario es false ! entonces te da mensaje de error
//lo mismo con verificar Contrasenia
//desp cera un nuevoCensista usando la clase y lo pushea al array usuariosCreados
function registrarCensista(nombre, usuario, contraseña) {
    if (!verificarNombreUsuarioUnico(usuario)) {
        alert("El nombre de usuario ya está en uso. Por favor, elige otro.");
        return;
    }
    if (!verificarContraseñaValida(contraseña)) {
        alert("La contraseña no cumple con los requisitos mínimos.");
        return;
    }
    let nuevoCensista = new Censista(nombre, usuario, contraseña);
    censistas.push(nuevoCensista)
    usuariosCreados.push(nuevoCensista);
    alert("Censista registrado con éxito.");
    document.querySelector("#txtNombre1").value = '';
    document.querySelector("#txtUsuario1").value = '';
    document.querySelector("#txtContraseña1").value = '';
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
}

function tomarValores1() {
    let nombre = document.querySelector("#txtNombre1").value;
    let usuario = document.querySelector("#txtUsuario1").value;
    let contraseña = document.querySelector("#txtContraseña1").value;

    //aca se verifica que los campos no esten vacios y si los estan, te tira un alert para q los llenes
    if (nombre.trim() === '') {
        alert("El campo de nombre es obligatorio.");
        return;
    }

    if (usuario.trim() === '') {
        alert("El campo de usuario es obligatorio.");
        return;
    }

    if (contraseña.trim() === '') {
        alert("El campo de contraseña es obligatorio.");
        return;
    }


    if (contraseña.length < 5) {
        alert("La contraseña debe tener al menos 5 caracteres.");
        return;
    }

    let tieneMinusc = false;
    let tieneMayusc = false;
    let tieneNumero = false;

    for (let i = 0; i < contraseña.length; i++) {
        const char = contraseña[i];

        if (char >= 'a' && char <= 'z') {
            tieneMinusc = true;
        } else if (char >= 'A' && char <= 'Z') {
            tieneMayusc = true;
        } else if (char >= '0' && char <= '9') {
            tieneNumero = true;
        }
    }

    if (!tieneMinusc) {
        alert("La contraseña debe contener al menos una letra minúscula.");
        return;
    }

    if (!tieneMayusc) {
        alert("La contraseña debe contener al menos una letra mayúscula.");
        return;
    }

    if (!tieneNumero) {
        alert("La contraseña debe contener al menos un número.");
        return;
    }

    registrarCensista(nombre, usuario, contraseña);
}

//Este boton toma los valores del campo de texto y ejecuta la funcion registrarCensista que tiene ejecuta otras funciones tambien
//tambien chequea de que la contrasenia tenga los requerimientos obligatorios
document.querySelector("#btnRegistrar").addEventListener("click", tomarValores1);
//1111111111111111111111111111111111111111111111111111111111111






let usuarioActivo = ""
//2222222222222222222222222222222222222222222222222222222222222222
// CREO UN ARARY DE CENSISTAS CON 3 USUARIOS PRE CARGADOS
let censistas = [
];
//AL HACER CLICK TOMA VALORES DE CAMPO
document.querySelector('#btnIngresar').addEventListener('click', function () {
    let usuario = document.querySelector('#txtUsuario2').value;
    let contraseña = document.querySelector('#txtContraseña2').value;
    // ACA DECLARA censitaValido como NULL y PASA POR LA FUNCION DE VALIDARCREDENCIALES, SI LAS CREDENCIALES QUE PUSISTE ESTAN EN EL ARRAY DE CENSISTAS, SE AGREGA A la variable CensistaVALIDO
    let censistaValido = null;
    for (let i = 0; i < censistas.length; i++) {
        let censista = censistas[i];
        if (censista.validarCredenciales(usuario, contraseña)) {
            censistaValido = censista;
            break;
        }
    }
    //SI CENSISTA ES VALIDO TE MANDA A LA PAGINA INGRESAR DATOS SINO TE DICE DA ERROR
    if (censistaValido) {
        // Credenciales correctas
        usuarioActivo = censistaValido.nombre;
        document.querySelector("#txtUsuarioCensistaActivo").innerHTML = ""
        document.querySelector("#txtUsuarioCensistaActivo").innerHTML = "Usuario Activo: " + usuarioActivo
        cambiarSeccion("seccionIngresarDatos")
        cargarPersonasPendientes();
        cargarCensistasDisponibles();

    } else {
        // Credenciales incorrectas
        alert('Credenciales incorrectas. Por favor, verifícalas.');
    }
    document.querySelector('#txtUsuario2').value = ""
    document.querySelector('#txtContraseña2').value = ""
});
//2222222222222222222222222222222222222222222222222222222222222222



//3333333333333333333333333333333333333333333333333333333333333333
console.log("escribiendo: personas muestra el array de objetos de la clase personas, escribiendo cedulasCensadas muestra array de cedulas, DESP BORRA ESTO")
//CREE CLASE PARA CADA PERSONA QUE SE QUIERA CENSAR
class Persona {
    constructor(nombre, apellido, edad, cedula, departamento, ocupacion, censado, censista) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.cedula = cedula;
        this.departamento = departamento;
        this.ocupacion = ocupacion;
        this.censado = censado;
        this.censista = censista;
    }
}
//Declaro variables de los Selec para mas adelante
let departamentoSelect = document.querySelector("#txtDepartamento3");
let cedulaInput = document.querySelector("#txtCedula3");
let ocupacionSelect = document.querySelector("#txtOcupacion3");
let censadoSelect = document.querySelector('#txtCensado3')
//Declaro arrays global de cedulas y el de la clase personas
let cedulasCensadas = ["1234"];

let departamentos = [
    "Artigas",
    "Canelones",
    "Cerro Largo",
    "Colonia",
    "Durazno",
    "Flores",
    "Florida",
    "Lavalleja",
    "Maldonado",
    "Montevideo",
    "Paysandú",
    "Río Negro",
    "Rivera",
    "Rocha",
    "Salto",
    "San José",
    "Soriano",
    "Tacuarembó",
    "Treinta y Tres"
];
//un pequeño array con los departamentos jaja
function cargarDepartamentos() {
    //recorre el array de departamentos y los carga dinamicamente en el option del HTML
    //asi podes evitar tener que escribir manualmente cada opción en el HTML y te deja modificar/agregar los departamentos en el array, sin tener que tocar el HTML
    for (let i = 0; i < departamentos.length; i++) {
        let departamento = departamentos[i];
        let option = document.createElement("option");
        option.value = departamento;
        option.textContent = departamento; // text content seria como InnerHTML pero en este escenario seria mas adecuado, sino tendriamos q escribir todo el HTML en el js
        departamentoSelect.appendChild(option); //se inserta el elemento option como una nueva opción dentro del menú desplegable, y se repite hasta terminar el bucle
    }
}

function validarCedula(cedula) {
    return true; // Lógica de validación de cédula
}

function esCedulaDuplicada(cedula) {
    return cedulasCensadas.includes(cedula);//si la cedula ingresada inculdes CEDULA entonces es que la cedula ya existe
}
// a continuacion, hice el mejor verificador de todos los tiempos
//verifica si algun campo quedo vacio, si ninguna cedula ya fue ingresada y si alguna cedula no es valida 
function validarFormulario() {
    let nombre = document.querySelector("#txtNombre3").value.trim();// ELIMINA ESPACIOS EN BLANCO AL PRINCIPIO Y FINAL
    let apellido = document.querySelector("#txtApellido3").value.trim();// ELIMINA ESPACIOS EN BLANCO AL PRINCIPIO Y FINAL
    let edad = document.querySelector("#txtEdad3").value;
    let cedula = cedulaInput.value.replace(/[^0-9]/g, "");//remueve puntos guiones espacios letras TODO lo q no sea numeros lo remueve
    let departamento = departamentoSelect.value;
    let ocupacion = ocupacionSelect.value;
    let censado = censadoSelect.value;

    //verifica si algun campo quedo vacio

    if (usuarioActivo === "") {
        alert("Debe Ingresar con su Nombre, Usuario y Contraseña primero.");
        return false;
    }

    if (nombre === "") {
        alert("El nombre no puede estar vacío.");
        return false;
    }

    if (apellido === "") {
        alert("El apellido no puede estar vacío.");
        return false;
    }

    if (edad === "") {
        alert("La edad no puede estar vacía.");
        return false;
    }
    if (!(edad > 0 && edad < 130)) {
        alert("La edad es Incorrecta.");
        return false;
    }

    if (cedula === "") {
        alert("La cédula no puede estar vacía.");
        return false;
    }

    if (departamento === "") {
        alert("Debe seleccionar un departamento de residencia.");
        return false;
    }

    if (ocupacion === "") {
        alert("Debe seleccionar una ocupación.");
        return false;
    }
    //verifica si la cedula ya esta censada
    if (esCedulaDuplicada(cedula)) {
        alert("Ya existe una persona censada para esta cédula.");
        return false;
    }
    //verifica si la cedula es valida
    if (!validarCedula(cedula)) {
        alert("La cédula ingresada no es válida.");
        return false;
    }
    if (censado === "") {
        alert("El campo Censado no puede quedar vacio")
        return false;
    }

    return true; // si pasa todas las verificaciones returnea TRUE, sino returnea false y tira alert
}


//ejecuto funcion para cargar los departamentos
cargarDepartamentos();

//al hacer click GUARDAR ejecuta la gran funcion validarFormulario(), si devuelve true, crea el objeto Persona y 
//lo agrega al array de personas, y tambien guarda la cedula en el array de cedulasCensadas
document.querySelector("#btnAgregar").addEventListener("click", function () {
    if (validarFormulario()) {
        let nombre = document.querySelector("#txtNombre3").value.trim();
        let apellido = document.querySelector("#txtApellido3").value.trim();
        let edad = document.querySelector("#txtEdad3").value;
        let cedula = cedulaInput.value.replace(/[^0-9]/g, "");
        let departamento = departamentoSelect.value;
        let ocupacion = ocupacionSelect.value;
        const censadoSelect = document.querySelector('#txtCensado3');
        const censadoValue = censadoSelect.value === "true"; // Convertir a booleano

        //let censista = USUARIO QUE LOGEASTE COMO CENSISTA
        const persona = new Persona(nombre, apellido, edad, cedula, departamento, ocupacion, censadoValue, usuarioActivo);;//crea el objeto nuevo Persona
        // if (censadoSelect.value === "false") {
        //     persona.censado = false
        // }
        personas.push(persona); // pushea al array de personas


        cedulasCensadas.push(cedula);// pushea al array de cedulas

        //mando un mensaje de notificacion con todos los datos que se cargaron al array de personas
        alert(`Datos válidos, se pueden guardar.
        Nombre: ${persona.nombre}
        Apellido: ${persona.apellido}
        Edad: ${persona.edad}
        Cédula: ${persona.cedula}
        Departamento: ${persona.departamento}
        Ocupación: ${persona.ocupacion}`);
        //resetea los campos de texto nuevamente para volver a ingresar nuevos textos
        document.querySelector("#txtNombre3").value = "";
        document.querySelector("#txtApellido3").value = "";
        document.querySelector("#txtEdad3").value = "";
        cedulaInput.value = "";
        departamentoSelect.value = "";
        ocupacionSelect.value = "";
    }
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
});


//3333333333333333333333333333333333333333333333333333333333333333






//4444444444444444444444444444444444444444444444444444444444444444
document.querySelector("#btnVerificar").addEventListener('click', verificarDatos);
let verificar = []
function verificarDatos() {
    verificar.splice(0, verificar.length)
    let cedula = document.querySelector('#txtCedula4').value;
    let personaEncontrada = null;

    if (cedula === "") {
        alert("El campo no puede estar vacío");
        return false;
    }

    for (let i = 0; i < personas.length; i++) {
        if (personas[i].cedula === cedula) {
            if (personas[i].censado === true) {
                document.querySelector('#pVerificar').innerHTML = 'La cédula ya está Censada.';
                return false;
            } else {
                personaEncontrada = personas[i];
                break;
            }
        }
    }


    if (personaEncontrada) {
        AgregarSeccion("seccionIngresarDatos");
        document.querySelector("#btnConfirmar").removeAttribute("hidden");
        document.querySelector("#btnAgregar").setAttribute("hidden", "true");
        document.querySelector('#txtNombre3').value = personaEncontrada.nombre;
        document.querySelector('#txtApellido3').value = personaEncontrada.apellido;
        document.querySelector('#txtEdad3').value = personaEncontrada.edad;
        document.querySelector("#txtCedula3").value = personaEncontrada.cedula;
        document.querySelector('#txtDepartamento3').value = personaEncontrada.departamento;
        document.querySelector('#txtOcupacion3').value = personaEncontrada.ocupacion;
        document.querySelector('#txtCensado3').value = personaEncontrada.censado.toString();
    } else {
        document.querySelector('#pVerificar').innerHTML = 'La cédula no fue encontrada.';
    }
    verificar.push(personaEncontrada)
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
}

document.querySelector("#btnConfirmar").addEventListener("click", ValidarCenso);

function ValidarCenso() {
    if (censadoSelect.value === "true") {
        verificar[0].censado = true;
        alert("Usuario Validado");
        cambiarSeccion("seccionVerificarDatos")
    } else if (censadoSelect.value === "false") {
        verificar[0].censado = false;
    }
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    //resetea los campos de texto nuevamente para volver a ingresar nuevos textos
    document.querySelector("#txtNombre3").value = "";
    document.querySelector("#txtApellido3").value = "";
    document.querySelector("#txtEdad3").value = "";
    cedulaInput.value = "";
    departamentoSelect.value = "";
    ocupacionSelect.value = "";
}

//444444444444444444444444444444444444444444444444444444444444444444444



//55555555555555555555555555555555555555555555555555555555555555555555
// Definición de la clase Persona
let ocupaciones = [
    "Dependiente",
    "Independiente",
    "Estudiante",
    "No trabaja"
];

let censista1 = new Censista("Juan", "juancensista", "123456");
let censista2 = new Censista("María", "mariacensista", "abcdef");
let censista3 = new Censista("Pedro", "pedrocensista", "789012");

censistas.push(censista1, censista2, censista3);
let personas = [
    new Persona("John", "Doe", 1, "1234567890", departamentos[0], ocupaciones[0], false, censistas[0].nombre),
    new Persona("Jane", "Smith", 32, "0987654321", departamentos[1], ocupaciones[2], false, censistas[1].nombre),
    new Persona("Michael", "Johnson", 40, "5678901234", departamentos[2], ocupaciones[1], false, censistas[2].nombre),
    new Persona("Emily", "Brown", 50, "4321098765", departamentos[3], ocupaciones[3], false, censistas[0].nombre),
    new Persona("Daniel", "Miller", 28, "9876543210", departamentos[4], ocupaciones[4], false, censistas[1].nombre),
    new Persona("Olivia", "Davis", 35, "3456789012", departamentos[5], ocupaciones[2], false, censistas[2].nombre),
    new Persona("David", "Wilson", 45, "2109876543", departamentos[6], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Sophia", "Moore", 55, "6543210987", departamentos[7], ocupaciones[3], false, censistas[1].nombre),
    new Persona("Emma", "Taylor", 30, "8765432109", departamentos[8], ocupaciones[4], false, censistas[2].nombre),
    new Persona("Noah", "Anderson", 38, "9012345678", departamentos[9], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Liam", "Wilson", 42, "7654321098", departamentos[0], ocupaciones[2], true, censistas[1].nombre),
    new Persona("Ava", "Johnson", 29, "2345678901", departamentos[1], ocupaciones[3], true, censistas[2].nombre),
    new Persona("Ethan", "Miller", 48, "6789012345", departamentos[2], ocupaciones[1], true, censistas[0].nombre),
    new Persona("Mia", "Davis", 36, "5432109876", departamentos[3], ocupaciones[4], true, censistas[1].nombre),
    new Persona("Isabella", "Moore", 31, "8901234567", departamentos[4], ocupaciones[2], true, censistas[2].nombre),
    new Persona("James", "Taylor", 39, "4567890123", departamentos[5], ocupaciones[3], true, censistas[0].nombre),
    new Persona("Benjamin", "Anderson", 43, "0123456789", departamentos[6], ocupaciones[1], true, censistas[1].nombre),
    new Persona("Luna", "Smith", 27, "3210987654", departamentos[7], ocupaciones[4], true, censistas[2].nombre),
    new Persona("Elijah", "Johnson", 33, "7890123456", departamentos[8], ocupaciones[2], true, censistas[0].nombre),
    new Persona("Scarlett", "Brown", 41, "2109876543", departamentos[9], ocupaciones[3], true, censistas[1].nombre),
    new Persona("Oliver", "Miller", 17, "1111111111", departamentos[2], ocupaciones[1], true, censistas[0].nombre),
    new Persona("Sophia", "Young", 35, "2222222222", departamentos[4], ocupaciones[2], true, censistas[1].nombre),
    new Persona("William", "Wilson", 28, "3333333333", departamentos[6], ocupaciones[3], true, censistas[2].nombre),
    new Persona("Charlotte", "Anderson", 41, "4444444444", departamentos[8], ocupaciones[4], false, censistas[0].nombre),
    new Persona("James", "Johnson", 19, "5555555555", departamentos[1], ocupaciones[1], false, censistas[1].nombre),
    new Persona("Amelia", "Brown", 12, "6666666666", departamentos[3], ocupaciones[0], true, censistas[2].nombre),
    new Persona("Benjamin", "Smith", 37, "7777777777", departamentos[5], ocupaciones[2], true, censistas[0].nombre),
    new Persona("Ava", "Taylor", 23, "8888888888", departamentos[7], ocupaciones[3], false, censistas[1].nombre),
    new Persona("Noah", "Davis", 31, "9999999999", departamentos[9], ocupaciones[4], false, censistas[2].nombre),
    new Persona("Emily", "Wilson", 15, "1234567890", departamentos[0], ocupaciones[1], true, censistas[0].nombre),
    new Persona("Oliver", "Anderson", 34, "0987654321", departamentos[1], ocupaciones[2], true, censistas[1].nombre),
    new Persona("Isabella", "Johnson", 47, "2345678901", departamentos[2], ocupaciones[3], true, censistas[2].nombre),
    new Persona("Mia", "Brown", 25, "3456789012", departamentos[3], ocupaciones[4], false, censistas[0].nombre),
    new Persona("Lucas", "Smith", 11, "4567890123", departamentos[4], ocupaciones[1], false, censistas[1].nombre),
    new Persona("Sophia", "Taylor", 39, "5678901234", departamentos[5], ocupaciones[2], true, censistas[2].nombre),
    new Persona("Elijah", "Davis", 16, "6789012345", departamentos[6], ocupaciones[3], true, censistas[0].nombre),
    new Persona("Emma", "Wilson", 30, "7890123456", departamentos[7], ocupaciones[4], true, censistas[1].nombre),
    new Persona("William", "Anderson", 42, "8901234567", departamentos[8], ocupaciones[1], true, censistas[2].nombre),
    new Persona("Olivia", "Johnson", 22, "9012345678", departamentos[9], ocupaciones[2], true, censistas[0].nombre),
    // Nuevas personas:
    new Persona("Liam", "Brown", 13, "0123456789", departamentos[0], ocupaciones[3], true, censistas[1].nombre),
    new Persona("Amelia", "Smith", 32, "0987654321", departamentos[1], ocupaciones[4], false, censistas[2].nombre),
    new Persona("Alexander", "Taylor", 48, "2345678901", departamentos[2], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Ella", "Davis", 26, "3456789012", departamentos[3], ocupaciones[2], true, censistas[1].nombre),
    new Persona("Lucas", "Wilson", 10, "4567890123", departamentos[4], ocupaciones[3], false, censistas[2].nombre),
    new Persona("Sophia", "Anderson", 29, "5678901234", departamentos[5], ocupaciones[4], true, censistas[0].nombre),
    new Persona("Jackson", "Johnson", 38, "6789012345", departamentos[6], ocupaciones[1], true, censistas[1].nombre),
    new Persona("Ava", "Brown", 21, "7890123456", departamentos[7], ocupaciones[2], false, censistas[2].nombre),
    new Persona("Liam", "Smith", 14, "8901234567", departamentos[8], ocupaciones[3], true, censistas[0].nombre),
    new Persona("Emma", "Taylor", 33, "9012345678", departamentos[9], ocupaciones[4], true, censistas[1].nombre),
    new Persona("Benjamin", "Davis", 40, "0123456789", departamentos[0], ocupaciones[1], false, censistas[2].nombre),
    new Persona("Mia", "Wilson", 18, "0987654321", departamentos[1], ocupaciones[2], true, censistas[0].nombre),
    new Persona("Lucas", "Anderson", 27, "2345678901", departamentos[2], ocupaciones[3], false, censistas[1].nombre),
    new Persona("Charlotte", "Johnson", 43, "3456789012", departamentos[3], ocupaciones[4], true, censistas[2].nombre),
    new Persona("James", "Brown", 20, "4567890123", departamentos[4], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Olivia", "Smith", 36, "5678901234", departamentos[5], ocupaciones[2], true, censistas[1].nombre),
    new Persona("Alexander", "Taylor", 9, "6789012345", departamentos[6], ocupaciones[3], true, censistas[2].nombre),
    new Persona("Emma", "Davis", 24, "7890123456", departamentos[7], ocupaciones[4], false, censistas[0].nombre),
    new Persona("Noah", "Wilson", 44, "8901234567", departamentos[8], ocupaciones[1], false, censistas[1].nombre),
    new Persona("Sophia", "Anderson", 28, "9012345678", departamentos[9], ocupaciones[2], true, censistas[2].nombre),
    new Persona("William", "Johnson", 16, "0123456789", departamentos[0], ocupaciones[3], true, censistas[0].nombre),
    new Persona("Ava", "Brown", 31, "0987654321", departamentos[1], ocupaciones[4], true, censistas[1].nombre),
    new Persona("Oliver", "Smith", 49, "2345678901", departamentos[2], ocupaciones[1], false, censistas[2].nombre),
    new Persona("Emily", "Taylor", 37, "3456789012", departamentos[3], ocupaciones[2], true, censistas[0].nombre),
    new Persona("James", "Davis", 11, "4567890123", departamentos[4], ocupaciones[3], false, censistas[1].nombre),
    new Persona("Isabella", "Wilson", 30, "5678901234", departamentos[5], ocupaciones[4], true, censistas[2].nombre),
    new Persona("Benjamin", "Anderson", 17, "6789012345", departamentos[6], ocupaciones[1], true, censistas[0].nombre),
    new Persona("Sophia", "Johnson", 22, "7890123456", departamentos[7], ocupaciones[2], true, censistas[1].nombre),
    new Persona("Noah", "Brown", 39, "8901234567", departamentos[8], ocupaciones[3], true, censistas[2].nombre),
    new Persona("Mia", "Smith", 19, "9012345678", departamentos[9], ocupaciones[4], true, censistas[0].nombre),
    new Persona("Alexander", "Taylor", 12, "0123456789", departamentos[0], ocupaciones[1], false, censistas[1].nombre),
    new Persona("Sophia", "Davis", 33, "0987654321", departamentos[1], ocupaciones[2], true, censistas[2].nombre),
    new Persona("Oliver", "Wilson", 46, "2345678901", departamentos[2], ocupaciones[3], true, censistas[0].nombre),
    new Persona("Charlotte", "Anderson", 21, "3456789012", departamentos[3], ocupaciones[4], false, censistas[1].nombre),
    new Persona("James", "Johnson", 14, "4567890123", departamentos[4], ocupaciones[1], true, censistas[2].nombre),
    new Persona("Emma", "Brown", 38, "5678901234", departamentos[5], ocupaciones[2], true, censistas[0].nombre),
    new Persona("Lucas", "Smith", 25, "6789012345", departamentos[6], ocupaciones[3], true, censistas[1].nombre),
    new Persona("Sophia", "Taylor", 8, "7890123456", departamentos[7], ocupaciones[4], false, censistas[2].nombre),
    new Persona("Ava", "Davis", 35, "8901234567", departamentos[8], ocupaciones[1], true, censistas[0].nombre),
    new Persona("Liam", "Anderson", 23, "9012345678", departamentos[9], ocupaciones[2], true, censistas[1].nombre),
    new Persona("Oliver", "Miller", 17, "1111111111", departamentos[2], ocupaciones[1], true, censistas[0].nombre),
    new Persona("Sophia", "Young", 35, "2222222222", departamentos[4], ocupaciones[2], true, censistas[1].nombre),
    new Persona("William", "Wilson", 28, "3333333333", departamentos[6], ocupaciones[3], true, censistas[2].nombre),
    new Persona("Charlotte", "Anderson", 41, "4444444444", departamentos[8], ocupaciones[4], false, censistas[0].nombre),
    new Persona("James", "Johnson", 19, "5555555555", departamentos[1], ocupaciones[1], false, censistas[1].nombre),
    new Persona("Amelia", "Brown", 12, "6666666666", departamentos[3], ocupaciones[0], true, censistas[2].nombre),
    new Persona("Benjamin", "Smith", 37, "7777777777", departamentos[5], ocupaciones[2], true, censistas[0].nombre),
    new Persona("Ava", "Taylor", 23, "8888888888", departamentos[7], ocupaciones[3], false, censistas[1].nombre),
    new Persona("Noah", "Davis", 31, "9999999999", departamentos[9], ocupaciones[4], false, censistas[2].nombre),
    new Persona("Emily", "Wilson", 15, "1234567890", departamentos[10], ocupaciones[1], true, censistas[0].nombre),
    new Persona("Oliver", "Anderson", 34, "0987654321", departamentos[11], ocupaciones[2], true, censistas[1].nombre),
    new Persona("Isabella", "Johnson", 47, "2345678901", departamentos[12], ocupaciones[3], true, censistas[2].nombre),
    new Persona("Mia", "Brown", 25, "3456789012", departamentos[13], ocupaciones[4], false, censistas[0].nombre),
    new Persona("Lucas", "Smith", 11, "4567890123", departamentos[14], ocupaciones[1], false, censistas[1].nombre),
    new Persona("Sophia", "Taylor", 39, "5678901234", departamentos[15], ocupaciones[2], true, censistas[2].nombre),
    new Persona("Elijah", "Davis", 16, "6789012345", departamentos[6], ocupaciones[3], true, censistas[0].nombre),
    new Persona("Emma", "Wilson", 30, "7890123456", departamentos[17], ocupaciones[4], true, censistas[1].nombre),
    new Persona("William", "Anderson", 42, "8901234567", departamentos[17], ocupaciones[1], true, censistas[2].nombre),
    new Persona("Olivia", "Johnson", 22, "9012345678", departamentos[18], ocupaciones[2], true, censistas[0].nombre),
    new Persona("Liam", "Brown", 13, "0123456789", departamentos[18], ocupaciones[3], true, censistas[1].nombre),
    new Persona("Amelia", "Smith", 32, "0987654321", departamentos[1], ocupaciones[4], false, censistas[2].nombre),
];

// Obtén referencias a los elementos del DOM
let personasPendientesSelect = document.querySelector('#personas-pendientes');
let censistasSelect = document.querySelector('#censistas');
let btnReasignar = document.querySelector('#btnReasignar');

// Función para cargar las opciones de personas pendientes
function cargarPersonasPendientes() {
    // Limpia las opciones existentes
    personasPendientesSelect.innerHTML = '';

    // Crea la opción por defecto
    let optionDefault = document.createElement('option');
    optionDefault.value = '';
    optionDefault.textContent = 'Seleccione...';
    personasPendientesSelect.appendChild(optionDefault);

    for (let i = 0; i < personas.length; i++) {
        if (personas[i].censado === false) {
            let option = document.createElement('option');
            option.value = personas[i].cedula;
            option.textContent = `${personas[i].nombre} ${personas[i].apellido}, CENSISTA: ${personas[i].censista}`;
            personasPendientesSelect.appendChild(option);
        }
    }
}

// Función para cargar las opciones de censistas disponibles
function cargarCensistasDisponibles() {
    // Limpia las opciones existentes
    censistasSelect.innerHTML = '';

    // Crea la opción por defecto
    let optionDefault = document.createElement('option');
    optionDefault.value = '';
    optionDefault.textContent = 'Seleccione...';
    censistasSelect.appendChild(optionDefault);

    // Crea las opciones para cada censista disponible utilizando un bucle for
    for (let i = 0; i < censistas.length; i++) {
        let censista = censistas[i];
        if (censista.nombre !== usuarioActivo) {
            let option = document.createElement('option');
            option.value = censista.nombre;
            option.textContent = censista.nombre;
            censistasSelect.appendChild(option);
        }
    }


}

// Event listener para el botón de reasignar
btnReasignar.addEventListener('click', function () {
    if (usuarioActivo === "") {
        alert("Debe Ingresar con su Nombre, Usuario y Contraseña primero.");
        return false;
    }
    let cedulaSeleccionada = personasPendientesSelect.value;
    let censistaSeleccionado = censistasSelect.value;

    let personaSeleccionada = personas.find(function (persona) {
        return persona.cedula === cedulaSeleccionada;
    });
    if (personaSeleccionada) {
        personaSeleccionada.censista = censistaSeleccionado;
        alert(`Se ha reasignado a ${personaSeleccionada.nombre} ${personaSeleccionada.apellido} al censista ${censistaSeleccionado}.`);
    }
    cargarPersonasPendientes();
    cargarCensistasDisponibles();

});

// Llama a las funciones para cargar las opciones iniciales
cargarPersonasPendientes();
cargarCensistasDisponibles();

//5555555555555555555555555555555555555555555555555555555555555





//6666666666666666666666666666666666666666666666666666666666666666666666666666

let totalCensadas = 0;
let totalDepartamentos = {};
let totalPendientes = 0;
let totalPersonas = 0;
let totalMenores = 0;
let totalMayores = 0;
function cargarDepartamentos1() {
    let departamentoSelect = document.querySelector("#txtDepartamento");

    for (let i = 0; i < departamentos.length; i++) {
        let departamento = departamentos[i];
        let option = document.createElement("option");
        option.value = departamento;
        option.textContent = departamento;
        departamentoSelect.appendChild(option);
    }
}

// Llamar a la función para precargar los departamentos en el select
cargarDepartamentos1();

function visualizarInformacion() {
    totalPersonas = 0;
    totalCensadas = 0;
    totalDepartamentos = {};
    totalPendientes = 0;

    // Reiniciar los contadores
    document.querySelector("#txtCensadasMomento").textContent = "";
    document.querySelector("#txtCensadasDepartamento").innerHTML = "";
    document.querySelector("#txtPendientes").textContent = "";

    // Calcular la cantidad de personas censadas para cada departamento
    for (let i = 0; i < personas.length; i++) {
        totalPersonas++;
        if (personas[i].censado === true) {
            totalCensadas++;
            if (totalDepartamentos[personas[i].departamento]) {
                totalDepartamentos[personas[i].departamento]++;
            } else {
                totalDepartamentos[personas[i].departamento] = 1;
            }
        } else {
            totalPendientes++;
        }
    }

    let porcentajePendientes = (totalPendientes / totalPersonas) * 100;

    // Mostrar la información estadística en el HTML
    document.querySelector("#txtCensadasMomento").textContent = totalCensadas;

    let censadasDepartamentoHTML = "";
    for (const departamento in totalDepartamentos) {
        censadasDepartamentoHTML += "<li>" + departamento + ": " + totalDepartamentos[departamento] + "</li>";
    }
    document.querySelector("#txtCensadasDepartamento").innerHTML = censadasDepartamentoHTML;

    document.querySelector("#txtPendientes").textContent = porcentajePendientes.toFixed(2) + "%";
}

// Función para mostrar el porcentaje de personas censadas menores y mayores de edad
function mostrarPorcentajeEdad() {
    let departamento = document.querySelector("#txtDepartamento").value;
    let totalMenoresCensados = 0;
    let totalMayoresCensados = 0;
    let totalMayoresNoCensados = 0;
    let totalMenoresNoCensados = 0;
    let totales = 0;

    for (let i = 0; i < personas.length; i++) {
        if (personas[i].departamento === departamento) {
            if (personas[i].censado === true) {
                if (personas[i].edad < 18) {
                    totalMenoresCensados++;
                } else {
                    totalMayoresCensados++;
                }
            } else {
                if (personas[i].edad < 18) {
                    totalMenoresNoCensados++;
                } else {
                    totalMayoresNoCensados++;
                }
            }
        }
    }

    let totalMenores = totalMenoresCensados + totalMenoresNoCensados;
    let totalMayores = totalMayoresCensados + totalMayoresNoCensados;

    let porcentajeMenores = (totalMenoresCensados / totalMenores) * 100;
    let porcentajeMayores = (totalMayoresCensados / totalMayores) * 100;

    document.querySelector("#txtPorcentajeMenores").textContent = porcentajeMenores.toFixed(2) + "%";
    document.querySelector("#txtPorcentajeMayores").textContent = porcentajeMayores.toFixed(2) + "%";

    // Reiniciar los contadores
    totalMenoresCensados = 0;
    totalMayoresCensados = 0;
    totalMayoresNoCensados = 0;
    totalMenoresNoCensados = 0;
    totales = 0;
}



// Asignar los eventos a los elementos correspondientes
document.querySelector("#btnVisualizarInformacion").addEventListener("click", visualizarInformacion);
document.querySelector("#btnMostrarPorcentajeEdad").addEventListener("click", mostrarPorcentajeEdad);
