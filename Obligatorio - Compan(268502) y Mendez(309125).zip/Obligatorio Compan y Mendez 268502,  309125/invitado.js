//PERFIL INVITADO
//INGRESAR DATOS
//RESET DE CAMPOS DE TEXTO Y MOSTRAR BOTONES CORRECTOS
function IngresarDatosInvitado() {
    AgregarSeccion("seccionIngresarDatos");
    document.querySelector("#divCensado").setAttribute("hidden", "true");
    document.querySelector("#btnAgregar").removeAttribute("hidden");
    document.querySelector("#btnAgregarInvitado").setAttribute("hidden", "true");
    document.querySelector("#btnConfirmar").setAttribute("hidden", "true");
    document.querySelector("#pMensajeEliminar").innerHTML = "";
    document.querySelector("#pMensajeInvitado").innerHTML = "";
    document.querySelector("#txtPorcentajeMayores").innerHTML = "";
    document.querySelector("#pVisualizarInformacion").innerHTML = "";
    document.querySelector("#pReasignarPersona").innerHTML = "";
    document.querySelector("#pVerificar").innerHTML = "";
    document.querySelector("#pMensajes").innerHTML = "";
    document.querySelector("#pIngresarCensista").innerHTML = "";
    document.querySelector("#pRegistrarCensista").innerHTML = "";
    document.querySelector("#pMensajes").innerHTML = "";
    document.querySelector("#txtCedulaInvitado1").value = ''
    document.querySelector("#txtCedulaEliminar").value = ''
    document.querySelector("#txtNombre1").value = '';
    document.querySelector("#txtUsuario1").value = '';
    document.querySelector("#txtContraseña1").value = '';
    document.querySelector('#txtUsuario2').value = ""
    document.querySelector('#txtContraseña2').value = ""
    document.querySelector("#txtNombre3").value = "";
    document.querySelector("#txtApellido3").value = "";
    document.querySelector("#txtEdad3").value = "";
    cedulaInput.value = "";
    departamentoSelect.value = "";
    ocupacionSelect.value = "";
    document.querySelector("#txtCensadasMomento").textContent = "";
    document.querySelector("#txtCensadasDepartamento").innerHTML = "";
    document.querySelector("#txtPendientes").textContent = "";
    document.querySelector("#txtDepartamento").value = ''
    document.querySelector("#txtCedula4").value = ''
    document.querySelector("#txtPorcentajeMenores").textContent = ''
    document.querySelector("#txtPorcentajeMayores").textContent = ''
}
function verificarDatosInvitado() {
    let cedula = document.querySelector('#txtCedulaInvitado1').value;
    let personaEncontrada = null;
    if (cedula === "") {
        document.querySelector("#pMensajeInvitado").innerHTML = "El campo no puede estar vacío";
        return false;
    }
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].cedula === cedula) {
            if (personas[i].censado === true) {
                document.querySelector('#pMensajeInvitado').innerHTML = 'La cédula ya está Censada.';
                return false;
            } else {
                personaEncontrada = personas[i];
                break;
            }
        }
    }
    if (personaEncontrada) {
        AgregarSeccion("seccionIngresarDatos");
        document.querySelector("#txtCedula3").setAttribute("disabled", "disabled");
        document.querySelector("#divCensado").setAttribute("hidden", "true");
        document.querySelector("#btnAgregarInvitado").removeAttribute("hidden");
        document.querySelector("#btnAgregar").setAttribute("hidden", "true");
        document.querySelector("#btnConfirmar").setAttribute("hidden", "true");
        document.querySelector('#txtNombre3').value = personaEncontrada.nombre;
        document.querySelector('#txtApellido3').value = personaEncontrada.apellido;
        document.querySelector('#txtEdad3').value = personaEncontrada.edad;
        document.querySelector("#txtCedula3").value = personaEncontrada.cedula;
        document.querySelector('#txtDepartamento3').value = personaEncontrada.departamento;
        document.querySelector('#txtOcupacion3').value = personaEncontrada.ocupacion;
        document.querySelector('#txtCensado3').value = personaEncontrada.censado.toString();
    } else {
        document.querySelector('#pMensajeInvitado').innerHTML = 'La cédula no fue encontrada, Porfavor Ingrese sus datos.';
    }

    cargarPersonasPendientes();
    cargarCensistasDisponibles();
}
function AgregarInvitado() {
    let cedula = document.querySelector('#txtCedulaInvitado1').value;
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].cedula === cedula) {
            personaEncontrada = personas[i];
            break;
        }
    }
    let nombre = document.querySelector("#txtNombre3").value.trim();
    let apellido = document.querySelector("#txtApellido3").value.trim();
    let edad = document.querySelector("#txtEdad3").value;
    let departamento = departamentoSelect.value;
    let ocupacion = ocupacionSelect.value; // Convertir a booleano
    let censista = asignarCensistaAleatorio()
    if (nombre === "") {
        document.querySelector("#pMensajeInvitado").innerHTML = "El nombre no puede estar vacío.";
        return false;
    }
    if (apellido === "") {
        document.querySelector("#pMensajeInvitado").innerHTML = "El apellido no puede estar vacío.";
        return false;
    }
    if (edad === "") {
        document.querySelector("#pMensajeInvitado").innerHTML = "La edad no puede estar vacía.";
        return false;
    }
    if (!(edad > 0 && edad < 130)) {
        document.querySelector("#pMensajeInvitado").innerHTML = "La edad es Incorrecta.";
        return false;
    }
    if (cedula === "") {
        document.querySelector("#pMensajeInvitado").innerHTML = "La cédula no puede estar vacía.";
        return false;
    }
    if (departamento === "") {
        document.querySelector("#pMensajeInvitado").innerHTML = "Debe seleccionar un departamento de residencia.";
        return false;
    }
    if (ocupacion === "") {
        document.querySelector("#pMensajeInvitado").innerHTML = "Debe seleccionar una ocupación.";
        return false;
    }
    personaEncontrada.nombre = nombre
    personaEncontrada.apellido = apellido
    personaEncontrada.edad = edad
    personaEncontrada.departamento = departamento
    personaEncontrada.ocupacion = ocupacion
    personaEncontrada.censadoValue = false
    personaEncontrada.censista = censista
    document.querySelector("#pMensajeInvitado").innerHTML = `Datos Guardados.
        Nombre: ${personaEncontrada.nombre}
        Apellido: ${personaEncontrada.apellido}
        Edad: ${personaEncontrada.edad}
        Cédula: ${personaEncontrada.cedula}
        Departamento: ${personaEncontrada.departamento}
        Ocupación: ${personaEncontrada.ocupacion}
        Censista: ${personaEncontrada.censista}`;
    //RESET DE CAMPOS DE TEXTO
    document.querySelector("#txtNombre3").value = "";
    document.querySelector("#txtApellido3").value = "";
    document.querySelector("#txtEdad3").value = "";
    cedulaInput.value = "";
    departamentoSelect.value = "";
    ocupacionSelect.value = "";
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    document.querySelector("#txtCedula3").removeAttribute("disabled");
}
function asignarCensistaAleatorio() {
    const indiceAleatorio = Math.floor(Math.random() * censistas.length);
    const censistaAleatorio = censistas[indiceAleatorio].nombre;
    return censistaAleatorio;
}
//ASIGNA FUNCIONES A BOTONES CORRESPONDIENTES
document.querySelector("#btnIngresarDatosInvitado").addEventListener("click", IngresarDatosInvitado);
document.querySelector("#btnVerificarInvitado").addEventListener('click', verificarDatosInvitado);
document.querySelector("#btnAgregarInvitado").addEventListener("click", AgregarInvitado);
//ELIMINAR DATOS
function buscarDatos() {
    let cedula = document.querySelector('#txtCedulaEliminar').value;
    let personaEncontrada = null;
    if (cedula === "") {
        document.querySelector("#pMensajeEliminar").innerHTML = "El campo no puede estar vacío";
        return false;
    }
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].cedula === cedula) {
            if (personas[i].censado === true) {
                document.querySelector('#pMensajeEliminar').innerHTML = 'La cédula ya está Censada.';
                return false;
            } else {
                personaEncontrada = personas[i];
                break;
            }
        }
    }
    if (personaEncontrada) {
        let confirmacion = confirm(`Desea eliminar sus datos?
        Nombre: ${personaEncontrada.nombre}
        Apellido: ${personaEncontrada.apellido}
        Edad: ${personaEncontrada.edad}
        Cédula: ${personaEncontrada.cedula}
        Departamento: ${personaEncontrada.departamento}
        Ocupación: ${personaEncontrada.ocupacion}
        Censista: ${personaEncontrada.censista}`)
        if (confirmacion) {
            personas.splice(personaEncontrada, 1);
            document.querySelector('#pMensajeEliminar').innerHTML = `Datos Eliminados.`
        }
    } else {
        document.querySelector('#pMensajeEliminar').innerHTML = 'La cédula no fue encontrada.';
    }
}
//ASIGNA FUNCION A BOTON CORRESPONDIENTE
document.querySelector("#btnBuscar").addEventListener('click', buscarDatos);
//LISTA DE CENSADOS
function registrarDatos(departamentoElegir) {
    let contadores = {
        Estudiantes: 0,
        NoTrabaja: 0,
        IndependienteDependiente: 0,
        Censado: 0,
        noCensado: 0,
        totales: 0,
        porcentaje: 0,
    };
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].departamento === departamentoElegir) {
            contadores.totales++
            if (personas[i].ocupacion === "Estudiante") {
                contadores.Estudiantes++
            }
            if (personas[i].ocupacion === "No trabaja") {
                contadores.NoTrabaja++
            }
            if (personas[i].ocupacion === "Dependiente" || personas[i].ocupacion === "Independiente") {
                contadores.IndependienteDependiente++
            }
            if (personas[i].censado) {
                contadores.Censado++
            } else {
                contadores.noCensado++
            }
        }
    }
    contadores.porcentaje = (contadores.Censado / contadores.totales) * 100
    return contadores;
}
//EJECUCION DE FUNCION REGISRARDATOS PARA CADA DEPARTAMENTO
function cargarTabla() {
    var tabla = document.getElementById("tblListaCensados");
    var tbody = tabla.getElementsByTagName("tbody")[0];
    let Artigas = registrarDatos("Artigas")
    let Canelones = registrarDatos("Canelones")
    let CerroLargo = registrarDatos("Cerro Largo")
    let Durazno = registrarDatos("Durazno")
    let Flores = registrarDatos("Flores")
    let Florida = registrarDatos("Florida")
    let Lavalleja = registrarDatos("Lavalleja")
    let Maldonado = registrarDatos("Maldonado")
    let Montevideo = registrarDatos("Montevideo")
    let Paysandú = registrarDatos("Paysandú")
    let RíoNegro = registrarDatos("Río Negro")
    let Rivera = registrarDatos("Rivera")
    let Rocha = registrarDatos("Rocha")
    let Salto = registrarDatos("Salto")
    let SanJosé = registrarDatos("San José")
    let Soriano = registrarDatos("Soriano")
    let Tacuarembó = registrarDatos("Tacuarembó")
    let TreintayTres = registrarDatos("Treinta y Tres")
    const tbody1 = document.querySelector("#tblListaCensados tbody");
    tbody1.innerHTML = `
        <tr>
            <td>Artigas</td>
            <td>${Artigas.Estudiantes}</td>
            <td>${Artigas.NoTrabaja}</td>
            <td>${Artigas.IndependienteDependiente}</td>
            <td>${Artigas.porcentaje.toFixed(0)} %</td>
        </tr>
        <tr>
            <td>Canelones</td>
            <td>${Canelones.Estudiantes}</td>
            <td>${Canelones.NoTrabaja}</td>
            <td>${Canelones.IndependienteDependiente}</td>
            <td>${(Canelones.porcentaje.toFixed(0))} %</td>
        </tr>
        <tr>
            <td>CerroLargo</td>
            <td>${CerroLargo.Estudiantes}</td>
            <td>${CerroLargo.NoTrabaja}</td>
            <td>${CerroLargo.IndependienteDependiente}</td>
            <td>${(CerroLargo.porcentaje.toFixed(0))} %</td>
        </tr>
        <tr>
        <td>Durazno</td>
        <td>${Durazno.Estudiantes}</td>
        <td>${Durazno.NoTrabaja}</td>
        <td>${Durazno.IndependienteDependiente}</td>
        <td>${(Durazno.porcentaje.toFixed(0))} %</td>
        </tr>
        <tr>
        <td>Flores</td>
        <td>${Flores.Estudiantes}</td>
        <td>${Flores.NoTrabaja}</td>
        <td>${Flores.IndependienteDependiente}</td>
        <td>${(Flores.porcentaje.toFixed(0))} %</td>
        </tr>
        <tr>
        <td>Florida</td>
        <td>${Florida.Estudiantes}</td>
        <td>${Florida.NoTrabaja}</td>
        <td>${Florida.IndependienteDependiente}</td>
        <td>${(Florida.porcentaje.toFixed(0))} %</td>
        </tr>
        <tr>
        <td>Lavalleja</td>
        <td>${Lavalleja.Estudiantes}</td>
        <td>${Lavalleja.NoTrabaja}</td>
        <td>${Lavalleja.IndependienteDependiente}</td>
        <td>${((Lavalleja.porcentaje.toFixed(0)))} %</td>
        </tr>
        <tr>
        <td>Maldonado</td>
        <td>${Maldonado.Estudiantes}</td>
        <td>${Maldonado.NoTrabaja}</td>
        <td>${Maldonado.IndependienteDependiente}</td>
        <td>${(Maldonado.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Montevideo</td>
        <td>${Montevideo.Estudiantes}</td>
        <td>${Montevideo.NoTrabaja}</td>
        <td>${Montevideo.IndependienteDependiente}</td>
        <td>${(Montevideo.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Paysandú</td>
        <td>${Paysandú.Estudiantes}</td>
        <td>${Paysandú.NoTrabaja}</td>
        <td>${Paysandú.IndependienteDependiente}</td>
        <td>${(Paysandú.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>RìoNegro</td>
        <td>${RíoNegro.Estudiantes}</td>
        <td>${RíoNegro.NoTrabaja}</td>
        <td>${RíoNegro.IndependienteDependiente}</td>
        <td>${(RíoNegro.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Rivera</td>
        <td>${Rivera.Estudiantes}</td>
        <td>${Rivera.NoTrabaja}</td>
        <td>${Rivera.IndependienteDependiente}</td>
        <td>${(Rivera.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Rocha</td>
        <td>${Rocha.Estudiantes}</td>
        <td>${Rocha.NoTrabaja}</td>
        <td>${Rocha.IndependienteDependiente}</td>
        <td>${(Rocha.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Salto</td>
        <td>${Salto.Estudiantes}</td>
        <td>${Salto.NoTrabaja}</td>
        <td>${Salto.IndependienteDependiente}</td>
        <td>${(Salto.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>SanJosé</td>
        <td>${SanJosé.Estudiantes}</td>
        <td>${SanJosé.NoTrabaja}</td>
        <td>${SanJosé.IndependienteDependiente}</td>
        <td>${(SanJosé.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Soriano</td>
        <td>${Soriano.Estudiantes}</td>
        <td>${Soriano.NoTrabaja}</td>
        <td>${Soriano.IndependienteDependiente}</td>
        <td>${(Soriano.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>Tacuarembó</td>
        <td>${Tacuarembó.Estudiantes}</td>
        <td>${Tacuarembó.NoTrabaja}</td>
        <td>${Tacuarembó.IndependienteDependiente}</td>
        <td>${(Tacuarembó.porcentaje.toFixed(0))} %</td>
        </tr>
        <td>TreintayTres</td>
        <td>${TreintayTres.Estudiantes}</td>
        <td>${TreintayTres.NoTrabaja}</td>
        <td>${TreintayTres.IndependienteDependiente}</td>
        <td>${(TreintayTres.porcentaje.toFixed(0))} %</td>
        </tr>
        `;
}
//ASIGNA FUNCION A BOTON CORRESPONDIENTE
document.querySelector("#btnSeccionListaDeCensadosInvitado").addEventListener("click", cargarTabla)