//PERFIL CENSISTA
//CLASES, DATOS PRECARGADOS Y VARIABLES
//CLASE PARA USUARIOS CENSISTAS
class Censista {
    constructor(nombre, usuario, contraseña) {
        this.nombre = nombre.toLowerCase();
        this.usuario = usuario.toLowerCase();
        this.contraseña = contraseña;
    }
    validarCredenciales(usuario, contraseña) {
        return (
            this.usuario === usuario.toLowerCase() && this.contraseña === contraseña);
    }
}
//CLASE PARA CREAR NUEVAS PERSONAS A CENSAR/CENSADAS
class Persona {
    constructor(nombre, apellido, edad, cedula, departamento, ocupacion, censado, censista) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.cedula = cedula;
        this.departamento = departamento;
        this.ocupacion = ocupacion;
        this.censado = censado;
        this.censista = censista;
    }
}
//DEPARTAMENTOS A PRECARGAR
let usuarioActivo = ""
let censistas = [];
let departamentos = [
    "Artigas",
    "Canelones",
    "Cerro Largo",
    "Colonia",
    "Durazno",
    "Flores",
    "Florida",
    "Lavalleja",
    "Maldonado",
    "Montevideo",
    "Paysandú",
    "Río Negro",
    "Rivera",
    "Rocha",
    "Salto",
    "San José",
    "Soriano",
    "Tacuarembó",
    "Treinta y Tres"
];
//PRECARGAR OCUPACIONES PARA SELECT EN HTML
let ocupaciones = [
    "Dependiente",
    "Independiente",
    "Estudiante",
    "No trabaja"
];
//REGISTRAR CENSISTA
//FUNCIONES PARA VALIDAR REGISTRO
function verificarContraseñaValida(contraseña) {
    let tieneMinusc = false;
    let tieneMayusc = false;
    let tieneNumero = false;
    for (let i = 0; i < contraseña.length; i++) {
        let char = contraseña[i];
        if (char >= 'a' && char <= 'z') {
            tieneMinusc = true;
        } else if (char >= 'A' && char <= 'Z') {
            tieneMayusc = true;
        } else if (char >= '0' && char <= '9') {
            tieneNumero = true;
        }
    }
    return tieneMinusc && tieneMayusc && tieneNumero && contraseña.length >= 5;
}
function registrarCensista(nombre, usuario, contraseña) {
    if (!verificarContraseñaValida(contraseña)) {
        document.querySelector("#pRegistrarCensista").innerHTML = "La contraseña no cumple con los requisitos mínimos.";
        return;
    }
    let nuevoCensista = new Censista(nombre, usuario, contraseña);
    censistas.push(nuevoCensista)
    document.querySelector("#pRegistrarCensista").innerHTML = "Censista registrado con éxito.";
    document.querySelector("#txtNombre1").value = '';
    document.querySelector("#txtUsuario1").value = '';
    document.querySelector("#txtContraseña1").value = '';
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
}
function tomarValores1() {
    let nombre = document.querySelector("#txtNombre1").value;
    let usuario = document.querySelector("#txtUsuario1").value;
    let contraseña = document.querySelector("#txtContraseña1").value;
    for (let i = 0; i < censistas.length; i++) {
        if (censistas[i].nombre === nombre && censistas[i].usuario === usuario && censistas[i].contraseña === contraseña) {
            document.querySelector("#pRegistrarCensista").innerHTML = "El usuario que intentas crear ya existe."
            return false
        }
        if (censistas[i].usuario === usuario) {
            document.querySelector("#pRegistrarCensista").innerHTML = "Nombre de Usuario ya esta en uso, eliga otro."
            return false
        }
    }
    if (nombre.trim() === '') {
        document.querySelector("#pRegistrarCensista").innerHTML = "El campo de nombre es obligatorio.";
        return;
    }
    if (usuario.trim() === '') {
        document.querySelector("#pRegistrarCensista").innerHTML = "El campo de usuario es obligatorio.";
        return;
    }
    if (contraseña.trim() === '') {
        document.querySelector("#pRegistrarCensista").innerHTML = "El campo de contraseña es obligatorio.";
        return;
    }
    if (contraseña.length < 5) {
        document.querySelector("#pRegistrarCensista").innerHTML = "La contraseña debe tener al menos 5 caracteres.";
        return;
    }
    let tieneMinusc = false;
    let tieneMayusc = false;
    let tieneNumero = false;
    for (let i = 0; i < contraseña.length; i++) {
        const char = contraseña[i];
        if (char >= 'a' && char <= 'z') {
            tieneMinusc = true;
        } else if (char >= 'A' && char <= 'Z') {
            tieneMayusc = true;
        } else if (char >= '0' && char <= '9') {
            tieneNumero = true;
        }
    }
    if (!tieneMinusc) {
        document.querySelector("#pRegistrarCensista").innerHTML = "La contraseña debe contener al menos una letra minúscula.";
        return;
    }
    if (!tieneMayusc) {
        document.querySelector("#pRegistrarCensista").innerHTML = "La contraseña debe contener al menos una letra mayúscula.";
        return;
    }
    if (!tieneNumero) {
        document.querySelector("#pRegistrarCensista").innerHTML = "La contraseña debe contener al menos un número.";
        return;
    }
    registrarCensista(nombre, usuario, contraseña);
}
document.querySelector("#btnRegistrar").addEventListener("click", tomarValores1);
//INGRESAR CENSISTA
//FUNCION PARA VERIFICAR INGRESO CORRECTO DEL USUARIO CENSISTA
function IngresarCensista() {
    let usuario = document.querySelector('#txtUsuario2').value;
    let contraseña = document.querySelector('#txtContraseña2').value;
    let censistaValido = null;   // ACA DECLARA censitaValido como NULL y PASA POR LA FUNCION DE VALIDARCREDENCIALES
    if (usuario === '' || contraseña === '') {
        document.querySelector("#pIngresarCensista").innerHTML = "Campos Vacios";
        return false
    }
    for (let i = 0; i < censistas.length; i++) {
        let censista = censistas[i];
        if (censista.validarCredenciales(usuario, contraseña)) {
            censistaValido = censista;
            break;
        }
    }
    if (censistaValido) {    //SI CENSISTA ES VALIDO TE MANDA A LA PAGINA INGRESAR DATOS SINO TE DA ERROR
        usuarioActivo = censistaValido.nombre;
        document.querySelector("#btnUsuarioCensistaActivo").innerHTML = ""
        document.querySelector("#btnUsuarioCensistaActivo").innerHTML = "Usuario Activo: " + usuarioActivo
        cambiarSeccion("seccionIngresarDatos")
        cargarPersonasPendientes();
        cargarCensistasDisponibles();
        document.querySelector("#pIngresarCensista").innerHTML = "Censista Ingresado con exito"
    } else {
        document.querySelector("#pIngresarCensista").innerHTML = 'Credenciales incorrectas. Por favor, verifícalas.';
    }
    document.querySelector('#txtUsuario2').value = ""
    document.querySelector('#txtContraseña2').value = ""
    document.querySelector("#pMensajeEliminar").innerHTML = "";
    document.querySelector("#pMensajeInvitado").innerHTML = "";
    document.querySelector("#txtPorcentajeMayores").innerHTML = "";
    document.querySelector("#pVisualizarInformacion").innerHTML = "";
    document.querySelector("#pReasignarPersona").innerHTML = "";
    document.querySelector("#pVerificar").innerHTML = "";
    document.querySelector("#pMensajes").innerHTML = "";
    document.querySelector("#pIngresarCensista").innerHTML = "";
    document.querySelector("#pRegistrarCensista").innerHTML = "";
    document.querySelector("#pMensajes").innerHTML = "";
};
document.querySelector('#btnIngresar').addEventListener('click', IngresarCensista)
//INGRESAR DATOS
let departamentoSelect = document.querySelector("#txtDepartamento3");
let cedulaInput = document.querySelector("#txtCedula3");
let ocupacionSelect = document.querySelector("#txtOcupacion3");
let censadoSelect = document.querySelector('#txtCensado3')
function cargarDepartamentos() {
    for (let i = 0; i < departamentos.length; i++) {
        let departamento = departamentos[i];
        let option = document.createElement("option");
        option.value = departamento;
        option.textContent = departamento;
        departamentoSelect.appendChild(option);
    }
}
function validarFormulario() {
    document.querySelector("#pMensajes").innerHTML = "";
    let nombre = document.querySelector("#txtNombre3").value.trim();// ELIMINA ESPACIOS EN BLANCO AL PRINCIPIO Y FINAL
    let apellido = document.querySelector("#txtApellido3").value.trim();// ELIMINA ESPACIOS EN BLANCO AL PRINCIPIO Y FINAL
    let edad = document.querySelector("#txtEdad3").value;
    let cedula = cedulaInput.value.replace(/[^0-9]/g, "");//REMUEVE TODOS LOS CARACTERES QUE NO SEAN NUMEROS DEL 0 AL 9
    let departamento = departamentoSelect.value;
    let ocupacion = ocupacionSelect.value;
    let censado = censadoSelect.value;
    //VERIFICA SI ALGUN CAMPO QUEDO VACIO
    if (usuarioActivo === "invitado") {
    } else if (usuarioActivo === "") {
        document.querySelector("#pMensajes").innerHTML = "Debe Ingresar con su Nombre, Usuario y Contraseña primero.";
        return false;
    }
    if (nombre === "") {
        document.querySelector("#pMensajes").innerHTML = "El nombre no puede estar vacío.";
        return false;
    }
    if (apellido === "") {
        document.querySelector("#pMensajes").innerHTML = "El apellido no puede estar vacío.";
        return false;
    }
    if (edad === "") {
        document.querySelector("#pMensajes").innerHTML = "La edad no puede estar vacía.";
        return false;
    }
    if (!(edad > 0 && edad < 130)) {
        document.querySelector("#pMensajes").innerHTML = "La edad esta fuera de rango.";
        return false;
    }
    if (cedula === "") {
        document.querySelector("#pMensajes").innerHTML = "La cédula no puede estar vacía.";
        return false;
    }
    for (let i = 0; i < personas.length; i++) {
        if (cedula === personas[i].cedula) {
            document.querySelector("#pMensajes").innerHTML = "Ya existe una persona censada para esta cédula.";
            return false;
        }
    }
    if (departamento === "") {
        document.querySelector("#pMensajes").innerHTML = "Debe seleccionar un departamento de residencia.";
        return false;
    }
    if (ocupacion === "") {
        document.querySelector("#pMensajes").innerHTML = "Debe seleccionar una ocupación.";
        return false;
    }
    if (censado === "") {
        document.querySelector("#pMensajes").innerHTML = "El campo Censado no puede quedar vacio"
        return false;
    }
    return true; // COMPRUEBA QUE PASE TODOS LOS VERIFICADORES
}
function agregarDatos() {
    if (validarFormulario()) {
        let nombre = document.querySelector("#txtNombre3").value.trim();
        let apellido = document.querySelector("#txtApellido3").value.trim();
        let edad = document.querySelector("#txtEdad3").value;
        let cedula = cedulaInput.value.replace(/[^0-9]/g, "");
        let departamento = departamentoSelect.value;
        let ocupacion = ocupacionSelect.value;
        let censadoSelect = document.querySelector('#txtCensado3');
        let censadoValue = censadoSelect.value === "true"; // CONVIERTE A BOOLEANO
        let persona = new Persona(nombre, apellido, edad, cedula, departamento, ocupacion, censadoValue, usuarioActivo);;//crea el objeto nuevo Persona
        personas.push(persona);
        //MENSAJE DE NOTIFICACION CON LOS DATOS INGRESADOS
        document.querySelector("#pMensajes").innerHTML = `Datos válidos, se pueden guardar.
        Nombre: ${persona.nombre}
        Apellido: ${persona.apellido}
        Edad: ${persona.edad}
        Cédula: ${persona.cedula}
        Departamento: ${persona.departamento}
        Ocupación: ${persona.ocupacion}`;
        //RESET DE CAMPOS DE TEXTO
        document.querySelector("#txtNombre3").value = "";
        document.querySelector("#txtApellido3").value = "";
        document.querySelector("#txtEdad3").value = "";
        cedulaInput.value = "";
        departamentoSelect.value = "";
        ocupacionSelect.value = "";
    }
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
};
document.querySelector("#btnAgregar").addEventListener("click", agregarDatos)
//VERIFICAR DATOS PRECARGADOS
function verificarDatos() {
    let cedula = document.querySelector('#txtCedula4').value;
    let personaEncontrada = null;
    //VERIFICA QUE UN USUARIO CENSISTA ESTE LOGUEADO
    if (usuarioActivo === "") {
        document.querySelector("#pVerificar").innerHTML = "Debe Ingresar con su Nombre, Usuario y Contraseña primero.";
        return false;
    }
    if (cedula === "") {
        document.querySelector("#pVerificar").innerHTML = "El campo no puede estar vacío";
        return false;
    }
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].cedula === cedula) {
            if (personas[i].censado === true) {
                document.querySelector('#pVerificar').innerHTML = 'La cédula ya está Censada.';
                return false;
            } else {
                personaEncontrada = personas[i];
                break;
            }
        }
    }
    if (personaEncontrada) {
        AgregarSeccion("seccionIngresarDatos");
        document.querySelector("#btnConfirmar").removeAttribute("hidden");
        document.querySelector("#txtCedula3").setAttribute("disabled", "disabled");
        document.querySelector("#btnAgregar").setAttribute("hidden", "true");
        document.querySelector('#txtNombre3').value = personaEncontrada.nombre;
        document.querySelector('#txtApellido3').value = personaEncontrada.apellido;
        document.querySelector('#txtEdad3').value = personaEncontrada.edad;
        document.querySelector("#txtCedula3").value = personaEncontrada.cedula;
        document.querySelector('#txtDepartamento3').value = personaEncontrada.departamento;
        document.querySelector('#txtOcupacion3').value = personaEncontrada.ocupacion;
        document.querySelector('#txtCensado3').value = personaEncontrada.censado.toString();
    } else {
        document.querySelector('#pVerificar').innerHTML = 'La cédula no fue encontrada.';
    }
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
}
function ValidarCenso() {
    let cedula = document.querySelector('#txtCedula3').value;
    let personaEncontrada = null;
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].cedula === cedula) {
            personaEncontrada = personas[i];
            if (censadoSelect.value === "true") {
                personaEncontrada.censado = true;
            } else if (personaEncontrada.value === "false") {
                personaEncontrada.censado = false;
            }
        }
    }
    let nombre = document.querySelector("#txtNombre3").value.trim();
    let apellido = document.querySelector("#txtApellido3").value.trim();
    let edad = document.querySelector("#txtEdad3").value;
    let departamento = departamentoSelect.value;
    let ocupacion = ocupacionSelect.value; // CONVIERTE A BOOLEANO
    personaEncontrada.nombre = nombre
    personaEncontrada.apellido = apellido
    personaEncontrada.edad = edad
    personaEncontrada.departamento = departamento
    personaEncontrada.ocupacion = ocupacion
    document.querySelector("#pVerificar").innerHTML = `Datos Guardados.
        Nombre: ${personaEncontrada.nombre}
        Apellido: ${personaEncontrada.apellido}
        Edad: ${personaEncontrada.edad}
        Cédula: ${personaEncontrada.cedula}
        Departamento: ${personaEncontrada.departamento}
        Ocupación: ${personaEncontrada.ocupacion}
        Censista: ${personaEncontrada.censista}`;
    cargarPersonasPendientes();
    cargarCensistasDisponibles();
    //RESET DE CAMPOS DE TEXTO
    document.querySelector("#txtNombre3").value = "";
    document.querySelector("#txtApellido3").value = "";
    document.querySelector("#txtEdad3").value = "";
    cedulaInput.value = "";
    departamentoSelect.value = "";
    ocupacionSelect.value = "";
    document.querySelector("#txtCedula3").removeAttribute("disabled")
}
document.querySelector("#btnVerificar").addEventListener('click', verificarDatos);
document.querySelector("#btnConfirmar").addEventListener("click", ValidarCenso);
//REASIGNAR PERSONA PARA VALIDAR
//ARRAY CENSISTAS CON 3 USUARIOS CENSISTAS
let censista1 = new Censista("Juan", "juancensista", "Contrasena1");
let censista2 = new Censista("María", "mariacensista", "Contrasena3");
let censista3 = new Censista("Pedro", "pedrocensista", "Contrasena3");
censistas.push(censista1, censista2, censista3);
//ARRAY DE OBJETOS(PERSONAS) CON 15 CENSADOS Y 15 NO CENSADOS
let personas = [
    new Persona("John", "Doe", 44, "12345678", departamentos[0], ocupaciones[0], false, censistas[0].nombre),
    new Persona("Jane", "Smith", 32, "09876543", departamentos[1], ocupaciones[2], false, censistas[1].nombre),
    new Persona("George", "Elin", 77, "56789012", departamentos[2], ocupaciones[1], false, censistas[2].nombre),
    new Persona("Emily", "Brown", 50, "43210987", departamentos[3], ocupaciones[3], false, censistas[0].nombre),
    new Persona("Daniel", "Miller", 28, "98765432", departamentos[4], ocupaciones[4], false, censistas[1].nombre),
    new Persona("Olivia", "Davis", 35, "34567890", departamentos[5], ocupaciones[2], false, censistas[2].nombre),
    new Persona("David", "Wilson", 45, "21098765", departamentos[6], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Sophia", "Moore", 55, "65432109", departamentos[7], ocupaciones[3], false, censistas[1].nombre),
    new Persona("Emma", "Taylor", 30, "87654321", departamentos[8], ocupaciones[4], false, censistas[2].nombre),
    new Persona("Noah", "Anderson", 38, "90123456", departamentos[9], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Liam", "Wilson", 42, "76543210", departamentos[10], ocupaciones[2], false, censistas[1].nombre),
    new Persona("Ava", "Johnson", 29, "23456789", departamentos[11], ocupaciones[3], false, censistas[2].nombre),
    new Persona("Ethan", "Miller", 48, "67890123", departamentos[12], ocupaciones[1], true, censistas[0].nombre),
    new Persona("Mia", "Davis", 36, "54321098", departamentos[13], ocupaciones[4], true, censistas[1].nombre),
    new Persona("Isabella", "Moore", 31, "89012345", departamentos[14], ocupaciones[2], true, censistas[2].nombre),
    new Persona("James", "Taylor", 39, "45678901", departamentos[15], ocupaciones[3], true, censistas[0].nombre),
    new Persona("Benjamin", "Anderson", 43, "01234567", departamentos[16], ocupaciones[1], true, censistas[1].nombre),
    new Persona("Luna", "Smith", 27, "32109876", departamentos[17], ocupaciones[4], true, censistas[2].nombre),
    new Persona("Elijah", "Johnson", 33, "78901234", departamentos[18], ocupaciones[2], true, censistas[0].nombre),
    new Persona("Scarlett", "Brown", 41, "21098763", departamentos[0], ocupaciones[3], true, censistas[1].nombre),
    new Persona("Alejandro", "Vazquez", 17, "11111111", departamentos[1], ocupaciones[1], true, censistas[2].nombre),
    new Persona("Sophia", "Young", 35, "22222222", departamentos[2], ocupaciones[2], true, censistas[0].nombre),
    new Persona("JuanIgnacio", "Mendez", 28, "33333333", departamentos[3], ocupaciones[3], true, censistas[1].nombre),
    new Persona("Charlotte", "Anderson", 41, "44444444", departamentos[4], ocupaciones[4], false, censistas[2].nombre),
    new Persona("Ignacio", "Compan", 19, "55555555", departamentos[5], ocupaciones[1], false, censistas[0].nombre),
    new Persona("Amelia", "Brown", 12, "66666666", departamentos[6], ocupaciones[0], true, censistas[1].nombre),
    new Persona("Benjamin", "Smith", 37, "77777777", departamentos[7], ocupaciones[2], true, censistas[2].nombre),
    new Persona("Ava", "Taylor", 23, "88888888", departamentos[8], ocupaciones[3], false, censistas[0].nombre),
    new Persona("Noah", "Davis", 31, "99999999", departamentos[9], ocupaciones[4], false, censistas[1].nombre),
    new Persona("Jorge", "Carrion", 31, "99999999", departamentos[10], ocupaciones[1], true, censistas[2].nombre),
];
let personasPendientesSelect = document.querySelector('#txtPersonasPendientes');
let censistasSelect = document.querySelector('#slcCensistas');
//FUNCION PARA CARGAR PERSONAS PENDIENTES DE VALIDAR
function cargarPersonasPendientes() {
    personasPendientesSelect.innerHTML = '';    // LIMPIA OPCIONES EXISTENTES
    let optionDefault = document.createElement('option');    //GENERA OPCION POR DEFECTO
    optionDefault.value = '';
    optionDefault.textContent = 'Seleccione...';
    personasPendientesSelect.appendChild(optionDefault);
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].censado === false) {
            let option = document.createElement('option');
            option.value = personas[i].cedula;
            option.textContent = `${personas[i].nombre} ${personas[i].apellido}, CENSISTA: ${personas[i].censista}`;
            personasPendientesSelect.appendChild(option);
        }
    }
}
//FUNCION PARA CARGAR CENSISTAS DISPONIBLES
function cargarCensistasDisponibles() {
    censistasSelect.innerHTML = '';    // LIMPIA OPCIONES EXISTENTES
    let optionDefault = document.createElement('option');    //GENERA OPCION POR DEFECTO
    optionDefault.value = '';
    optionDefault.textContent = 'Seleccione...';
    censistasSelect.appendChild(optionDefault);
    // CARGA CENSISTAS DISPONIBLES
    for (let i = 0; i < censistas.length; i++) {
        let censista = censistas[i];
        if (censista.nombre !== usuarioActivo) {
            let option = document.createElement('option');
            option.value = censista.nombre;
            option.textContent = censista.nombre;
            censistasSelect.appendChild(option);
        }
    }
}
document.querySelector('#btnReasignar').addEventListener('click', reasignarCensista)
function reasignarCensista() {
    //VERIFICA QUE UN USUARIO CENSISTA ESTE LOGUEADO
    if (usuarioActivo === "") {
        document.querySelector("#pReasignarPersona").innerHTML = "Debe Ingresar con su Nombre, Usuario y Contraseña primero.";
        return false;
    }
    if (personasPendientesSelect.value === "") {
        document.querySelector("#pReasignarPersona").innerHTML = "Seleccione una persona Pendiente de Validar"
        return false
    }
    if (censistasSelect.value === "") {
        document.querySelector("#pReasignarPersona").innerHTML = "Seleccione un Censista"
        return false
    }
    let cedulaSeleccionada = personasPendientesSelect.value;
    let censistaSeleccionado = censistasSelect.value;
    let personaSeleccionada = personas.find(function (persona) {
        return persona.cedula === cedulaSeleccionada;
    });
    if (personaSeleccionada.censista === censistaSeleccionado) {
        document.querySelector("#pReasignarPersona").innerHTML = "El censista ya esta asignado a este usuario."
    } else if (personaSeleccionada) {
        personaSeleccionada.censista = censistaSeleccionado;
        document.querySelector("#pReasignarPersona").innerHTML = `Se ha reasignado a ${personaSeleccionada.nombre} ${personaSeleccionada.apellido} al censista ${censistaSeleccionado}.`;
        cargarPersonasPendientes();
        cargarCensistasDisponibles();
    }
};
cargarPersonasPendientes();// CARGA DATOS DE PERSONAS PENDIENTES Y CENSISTAS DISPONIBLES AL PRINCIPIO DE LA APLICACION
cargarCensistasDisponibles();
//VISUALIZAR INFORMACION ESTADISTICA
//DECLARACION DE VARIABLES
let totalCensadas = 0;
let totalDepartamentos = {};
let totalPendientes = 0;
let totalPersonas = 0;
let totalMenores = 0;
let totalMayores = 0;
let porcentajeMenores = 0;
let porcentajeMayores = 0;
//CARGA DEPARTAMENTOS DINAMICAMENTE
function cargarDepartamentos1() {
    let departamentoSelect = document.querySelector("#txtDepartamento");
    let optionDefault = document.createElement('option');
    optionDefault.value = '';
    optionDefault.textContent = 'Seleccione...';
    departamentoSelect.appendChild(optionDefault);
    for (let i = 0; i < departamentos.length; i++) {
        let departamento = departamentos[i];
        let option = document.createElement("option");
        option.value = departamento;
        option.textContent = departamento;
        departamentoSelect.appendChild(option);
    }
}
cargarDepartamentos1();
function visualizarInformacion() {
    //VERIFICA QUE UN USUARIO CENSISTA ESTE LOGUEADO
    if (usuarioActivo === "") {
        document.querySelector("#pVisualizarInformacion").innerHTML = "Debe Ingresar con su Nombre, Usuario y Contraseña primero.";
        return false;
    }
    let departamento = document.querySelector("#txtDepartamento").value;

    totalPersonas = 0;
    totalCensadas = 0;
    totalDepartamentos = {};
    totalPendientes = 0;
    // REINICIA LOS CONTADORES
    document.querySelector("#txtCensadasMomento").textContent = "";
    document.querySelector("#txtCensadasDepartamento").innerHTML = "";
    document.querySelector("#txtPendientes").textContent = "";
    // CALCULA LA CANTIDAD DE PERSONAS CENSADAS PARA CADA DEPARTAMENTO
    for (let i = 0; i < personas.length; i++) {
        totalPersonas++;
        if (personas[i].censado === true) {
            totalCensadas++;
            if (totalDepartamentos[personas[i].departamento]) {
                totalDepartamentos[personas[i].departamento]++;
            } else {
                totalDepartamentos[personas[i].departamento] = 1;
            }
        } else {
            totalPendientes++;
        }
    }
    let porcentajePendientes = (totalPendientes / totalPersonas) * 100;
    //MUESTRA LA INFORMACION ESTADISTICA EN EL HTML
    document.querySelector("#txtCensadasMomento").textContent = totalCensadas;
    let censadasDepartamentoHTML = "";
    for (const departamento in totalDepartamentos) {
        censadasDepartamentoHTML += "<li>" + departamento + ": " + totalDepartamentos[departamento] + "</li>";
    }
    document.querySelector("#txtCensadasDepartamento").innerHTML = censadasDepartamentoHTML;
    document.querySelector("#txtPendientes").textContent = porcentajePendientes.toFixed(2) + "%";
}
//FUNCIONES PARA MOSTRAR PORCENTAJES DE EDAD MAYORES Y MENORES
function mostrarPorcentajeEdad() {
    //VERIFICA QUE UN USUARIO CENSISTA ESTE LOGUEADO
    document.querySelector("#pVisualizarInformacion").innerHTML = ""
    if (usuarioActivo === "") {
        document.querySelector("#pVisualizarInformacion").innerHTML = "Debe Ingresar con su Nombre, Usuario y Contraseña primero.";
        return false;
    }
    let departamento = document.querySelector("#txtDepartamento").value;
    if (departamento === '') {
        document.querySelector("#pVisualizarInformacion").innerHTML = "Seleccione un Departamento"
        return false
    }
    let totalMenoresCensados = 0;
    let totalMayoresCensados = 0;
    let totalMayoresNoCensados = 0;
    let totalMenoresNoCensados = 0;
    let totalMenores = 0;
    let totalMayores = 0;
    let porcentajeMenores = 0;
    let porcentajeMayores = 0;
    for (let i = 0; i < personas.length; i++) {
        if (personas[i].departamento === departamento) {
            if (personas[i].censado === true) {
                if (personas[i].edad < 18) {
                    totalMenoresCensados++;
                } else {
                    totalMayoresCensados++;
                }
            } else {
                if (personas[i].edad < 18) {
                    totalMenoresNoCensados++;
                } else {
                    totalMayoresNoCensados++;
                }
            }
        }
    }
    totalMenores = totalMenoresCensados + totalMenoresNoCensados;
    totalMayores = totalMayoresCensados + totalMayoresNoCensados;
    if (totalMenores !== 0) {
        porcentajeMenores = (totalMenoresCensados / totalMenores) * 100;
    }
    if (totalMayores !== 0) {
        porcentajeMayores = (totalMayoresCensados / totalMayores) * 100;
    }
    document.querySelector("#txtPorcentajeMenores").textContent = porcentajeMenores.toFixed(2) + "%";
    document.querySelector("#txtPorcentajeMayores").textContent = porcentajeMayores.toFixed(2) + "%";
    // REINICIA CONTADORES
    totalMenoresCensados = 0;
    totalMayoresCensados = 0;
    totalMayoresNoCensados = 0;
    totalMenoresNoCensados = 0;
}
// ASIGNAR EVENTOS A LOS BOTONES CORRESPONDIENTES
document.querySelector("#btnVisualizarInformacion").addEventListener("click", visualizarInformacion);
document.querySelector("#btnMostrarPorcentajeEdad").addEventListener("click", mostrarPorcentajeEdad);
cargarDepartamentos();